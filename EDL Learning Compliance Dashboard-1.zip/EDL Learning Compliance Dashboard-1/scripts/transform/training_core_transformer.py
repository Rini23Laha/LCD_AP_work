
from configs import mappings
from configs import training_core_mapping
from transform import Itransformer

from pyspark.sql.functions import col,lit,when
import pyspark.sql.functions as F
from  pyspark.sql.dataframe import DataFrame
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from awsglue.transforms import *

api_name="training_core"

class training_core_transformer(Itransformer.Itransformer):
    
    def transform(self,  spark_session, glue_dyn_frame, table_name,job_args:dict):
        dyf_source = glue_dyn_frame.resolveChoice(specs=[      
                ('object_id', 'cast:string'),
                ('lo_hours','cast:double')
                ])
        dyf_source.printSchema()
        mapping=mappings.api_table_mapping.get(api_name).get(table_name)
        transformed_data=ApplyMapping.apply(
                    frame=dyf_source,
                    mappings=mapping,
                    transformation_ctx="mapped_dyn_frame",
                        )

        transformed_data=transformed_data.toDF()   
        return transformed_data

        

        





        
        
