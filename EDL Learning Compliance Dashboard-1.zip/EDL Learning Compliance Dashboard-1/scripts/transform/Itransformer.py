

from abc import abstractmethod
from  pyspark.sql.dataframe import DataFrame
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext

class Itransformer:
    @abstractmethod
    def transform(self, spark_session, glue_dyn_frame, table_name,job_args:dict): raise NotImplementedError


    @abstractmethod
    def save_trasformed_data(self, spark_dataframe:DataFrame, glueContext: GlueContext, context_name:str,s3_path:str): raise NotImplementedError

    def save_trasformed_data(self, spark_dataframe:DataFrame, glueContext: GlueContext, context_name:str,s3_path:str):
        data_dyn_frame = DynamicFrame.fromDF(spark_dataframe, glueContext, context_name)            
        glueContext.write_dynamic_frame.from_options(frame=data_dyn_frame, connection_type="s3", connection_options={"path": s3_path},
                                                                        format="parquet", transformation_ctx=context_name+"_write")
        

    def save_trasformed_data(self, spark_dataframe:DataFrame, glueContext: GlueContext, context_name:str,s3_path:str):
        data_dyn_frame = DynamicFrame.fromDF(spark_dataframe, glueContext, context_name)     
        #output_path=contants.s3_processed_data_path_format.format(bucket="",prefix="",api_name=api_name,table_name=table_name,year=year,month=month,day=day)
        glueContext.write_dynamic_frame.from_options(frame=data_dyn_frame, connection_type="s3", connection_options={"path": s3_path},
                                                                        format="parquet", transformation_ctx=context_name+"_write")