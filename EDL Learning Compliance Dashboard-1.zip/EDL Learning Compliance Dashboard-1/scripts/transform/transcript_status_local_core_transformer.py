
from configs import mappings
from configs import transcript_status_local_core_mapping
from transform import Itransformer

from pyspark.sql.functions import col,lit,when
import pyspark.sql.functions as F
from  pyspark.sql.dataframe import DataFrame
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from awsglue.transforms import *

api_name="transcript_status_local_core"

class transcript_status_local_core_transformer(Itransformer.Itransformer):
    
    def transform(self,  spark_session, glue_dyn_frame, table_name,job_args:dict):
        dyf_source = glue_dyn_frame.resolveChoice(specs=[      

                ('is_default','cast:boolean'),
                ('_last_touched_dt_utc', 'cast:timestamp')

        ])
        dyf_source.printSchema()
        mapping=mappings.api_table_mapping.get(api_name).get(table_name)
        transformed_data=ApplyMapping.apply(
                    frame=dyf_source,
                    mappings=mapping,
                    transformation_ctx="mapped_dyn_frame",
                        )

        transformed_data=transformed_data.toDF()   
      
        
        return transformed_data

        

        





        
        
