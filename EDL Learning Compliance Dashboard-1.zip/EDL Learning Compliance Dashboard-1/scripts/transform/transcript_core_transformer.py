
from configs import mappings
from configs import transcript_core_mapping
from transform import Itransformer

from pyspark.sql.functions import col,lit,when
import pyspark.sql.functions as F
from  pyspark.sql.dataframe import DataFrame
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from awsglue.transforms import *
import logging

api_name="transcript_core"

class transcript_core_transformer(Itransformer.Itransformer):
    
    def transform(self,  spark_session, glue_dyn_frame, table_name,job_args:dict):
        logging.info("before_transformations")
        glue_dyn_frame.show(5)
        dyf_source = glue_dyn_frame.resolveChoice(specs=[ 
                ('user_lo_status_id', 'cast:long'),
                ('transc_user_id', 'cast:integer'),
                ('reg_num','cast:integer')
                

        ])
        dyf_source.printSchema()
        logging.info("after_resolve_choice")
        dyf_source.show(5)
        mapping=mappings.api_table_mapping.get(api_name).get(table_name)
        transformed_data=ApplyMapping.apply(
                    frame=dyf_source,
                    mappings=mapping,
                    transformation_ctx="mapped_dyn_frame",
                        )
        logging.info("after_apply_mapping")
        transformed_data.show(5)
        transformed_data=transformed_data.toDF()   
        transformed_data=transformed_data.withColumn("user_lo_assigned_dt_utc",F.to_timestamp(transformed_data["user_lo_assigned_dt"]))
        transformed_data=transformed_data.withColumn("user_lo_comp_dt_utc",F.to_timestamp(transformed_data["user_lo_comp_dt"]))
        transformed_data=transformed_data.withColumn("user_lo_min_due_date_utc",F.to_timestamp(transformed_data["user_lo_min_due_date"]))
        transformed_data=transformed_data.withColumn("user_lo_start_dt_utc",F.to_timestamp(transformed_data["user_lo_start_dt"]))
        return transformed_data

        

        





        
        
