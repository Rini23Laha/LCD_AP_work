from transform import ou_core_transformer
from transform import transcript_core_transformer
from transform import user_ou_core_transformer
from transform import training_cf_core_transformer
from transform import training_local_core_transformer
from transform import training_core_transformer
from transform import transcript_status_local_core_transformer
from transform import culture_core_transformer
from transform import curriculum_structure_core_transformer
from transform import users_core_transformer
from transform import address_core_transformer
from transform import Itransformer




class transformer_factory:

    @staticmethod
    def get_transformer(api_name: str)-> Itransformer.Itransformer:
        switcher = {
        "transcript_core": transcript_core_transformer.transcript_core_transformer(), 
        "ou_core": ou_core_transformer.ou_core_transformer(),
        "user_ou_core":user_ou_core_transformer.user_ou_core_transformer(),
        "training_cf_core":training_cf_core_transformer.training_cf_core_transformer(),
        "training_local_core":training_local_core_transformer.training_local_core_transformer(),
        "training_core":training_core_transformer.training_core_transformer(),
        "transcript_status_local_core":transcript_status_local_core_transformer.transcript_status_local_core_transformer(),
        "culture_core":culture_core_transformer.culture_core_transformer(),
        "curriculum_structure_core":curriculum_structure_core_transformer.curriculum_structure_core_transformer(),
        "users_core":users_core_transformer.users_core_transformer(),
        "address_core":address_core_transformer.address_core_transformer()
          

        }
        return switcher.get(api_name)