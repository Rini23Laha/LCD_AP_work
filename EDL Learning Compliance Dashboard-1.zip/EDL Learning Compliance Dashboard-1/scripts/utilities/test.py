# import requests
# import json

# url = "https://airproducts-pilot.csod.com/services/api/x/dataexporter/api/objects/transcript_core?$select=transc_object_id,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc&$filter=_last_touched_dt_utc gt cast('2022-06-01', Edm.DateTimeOffset) and _last_touched_dt_utc lt cast('2022-06-10', Edm.DateTimeOffset)"

# payload = {}
# headers = {
#   'prefer': 'odata.maxpagesize=1500',
#   'Authorization': 'Bearer ZWRnZQ:69ad2f7d3001fb95d1cd6912a42c2b991ef9890890778472e393686d5c0252c6',
#   'Cookie': 'ASP.NET_SessionId=sz0d3tznjyqvpzbgxmct4yab; AWSALB=BLu+vXL4JPSdgAJC7QXFhr30gbjea5IDgNMKEcoSPPuc88oEQj1hO2/Ff+xO8didOFUutJtXJHbvab4x4KAjnX2doIXEnChBDs71MYy2aek/WzVS9FRZqmhd6CYL3O2rbZj0NAHIZV+hVI9NWziYnCoGxqD5j7/g+YQzeIq0fgSlqcFjrTWj2MnN3nZ/Vg=='
# }

# response = requests.request("GET", url, headers=headers, data=payload)
# data=response.json()
# next_link=data["value"]
# print(type(data))
# for i in data:
#     if i=='@odata.nextLink':
#         next_link=data.get('@odata.nextLink')
#         new_response=requests.request("GET", next_link, headers=headers, data=payload)
#         new_data=new_response.json()
#         print(len(new_data))
#     else:
#         print("no data left")






# import os
# import sys

# root = os.path.dirname(os.path.realpath(os.getcwd()))
# deequ_jar = "https://repo1.maven.org/maven2/com/amazon/deequ/deequ/2.0.0-spark-3.1/deequ-2.0.0-spark-3.1.jar"
# classpath = f"{root}/jar/deequ-2.0.0-spark-3.1.jar"

# # !wget -q -O $classpath $deequ_jar

# import requests
# import json

# url = "https://airproducts-pilot.csod.com/services/api/x/dataexporter/api/objects/transcript_core?$select=transc_object_id,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc&$filter=_last_touched_dt_utc gt cast('2023-09-26', Edm.DateTimeOffset) and _last_touched_dt_utc lt cast('2023-09-27', Edm.DateTimeOffset)"

# payload = {}
# headers = {
#   'prefer': 'odata.maxpagesize=15',
#   'Authorization': 'Bearer ZWRnZQ:bc7b1a4947ad75dbb42b851e2bf74a0dc4e873f9cb05380aff3a8b3dfcd19c94',
#   'Cookie': 'ASP.NET_SessionId=ikyfyce0xjn0uw1l1zw4netk; AWSALB=KlXNenHTdE9T0LZq+dPnIcGQivpLUaY4fNW1/ZRkZsZ7cnQuav4roMpDNmB4c+WdSCnRsak1sJy+tWPdk00XOHisZjIi+2KgOb8WcKl8W55H8O479t/FtEC0AYZek0eC4IvB1NOLPlWzR+nD/qluvnM4iv3NCg0LJUqXJiOYc0veIxxYueCvotbyPJHdhg=='
# }
# all_delta_data=[]
# response = requests.request("GET", url, headers=headers, data=payload)
# delta_data=response.json()
# delta_value=response.json()["value"]
# delta_next_link=delta_data.get('@odata.nextLink')
# # print(delta_value)
# all_delta_data=response.json()["value"]

# response2=requests.request("GET", delta_next_link, headers=headers, data=payload)
# delta_value2=response2.json()
# all_delta_data.extend(delta_value2.get("value",[]))
# # print(len(all_delta_data))
# next_page_link=delta_next_link
# while next_page_link:
#     del_data_res=requests.request("GET", delta_next_link, headers=headers, data=payload)
#     del_val_res=del_data_res.json()
#     delta_next_link_=del_val_res.get('@odata.nextLink')
#     all_delta_data.extend(del_val_res.get("value",[]))
    
    
#     if not next_page_link:
#        break

# print(len(all_delta_data))


import requests
import json
api_url="https:///airproducts-pilot.csod.com/services/api/x/dataexporter/api/objects/transcript_core?$select=transc_object_id,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc&$filter=_last_touched_dt_utc gt cast('2023-09-27', Edm.DateTimeOffset)"
payload = {}
headers = {
  'prefer': 'odata.maxpagesize=1500',
  'Authorization': 'Bearer ZWRnZQ:e05a30ca2142cd112b2cf1af215a93297f9ab832c68f131c9c20b7504340be15',
  'Cookie': 'ASP.NET_SessionId=e14onr2w35f0avutjgt01qt2; AWSALB=qe8k66nKlFPQurC1IbKsfal5uc7cJ3fDcLhA0wsrwlOUMBaCaPG5GOfDOsHPspoG0MSnJlwjhG7ocuV37/mLcgZeNhRdvTfT5RU4TZjYmzsTjqqq3BhfxJRyu7fIlJAhy82mF3YY5NCD/ckwWoQT8D+Dfh5Ag0BYU0qqcn363mFQ9Ft0elEV255lagK6JQ=='
}

def get_api_data(url):
    response = requests.request("GET", url, headers=headers, data=payload)
    if response.status_code==200:
        return response.json()
    else:
        raise Exception(f"api resquest failed with statuscode{response.status_code}")
def print_all_pages(api_url):
                        data=get_api_data(api_url):
                        page_number=1
                        while api_url:
                          data=get_api_data(api_url)
                          print(f"pages{page_number}:{api_url}")
                          api_url=data.get('@odata.nextLink')
                          page_number += 1
if __name__=="__main__":
  print_all_pages(api_url)























        # -- WHERE field_10 = TRUE ;
        # -- removed 2023-11-24 approval of Claire.
        # -- "Do not show (Field_10 = FALSE) unless user is assigned a course from curriculum, then show just those courses."








# ## for full 
# 
# load or full load
# import requests
# import json

# url = "https://airproducts-pilot.csod.com/services/api/x/dataexporter/api/objects/transcript_core"
# #?$select=transc_object_id,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc"

# payload = {}
# headers = {
#   'prefer': 'odata.maxpagesize=10',
#   'Authorization': 'Bearer ZWRnZQ:dd1de360436e03e8b5d3a38fc54784b479eaa526c4dd671d7ca0960ba62bdab3',
#   'Cookie': 'ASP.NET_SessionId=kszotix5j3chsukp4bztcuhi; AWSALB=Kr3DfH4i5AZzMkM3ZdQVls4CcyFR/B7ZDUDWGZLGSr/icZleRbqtSzwsUrPiC+fwo+FrwNM6CNrgD6jCaRTYOAa1Dsn5b5b8HDKd5fFr1OoBkCakR1CoJgyLdlHkeAp35Zm++obYk6mQzmO8knkgcdxDw4xTpJ6Y36IqGhzyCPfUX2ixP1Ke9kGzgCc1Aw=='
# }

# # ###########giving the results of new
# response = requests.request("GET", url, headers=headers, data=payload)
# # #print(response.text)
# # data = json.loads(response.text)
# # #data['@odata.nextLink']
# # #url=data['@odata.nextLink']
# # next_data_link=str(data['@odata.nextLink'])
# # #print(next_data_link)

# # new_url=next_data_link
# # response2=requests.request("GET", new_url, headers=headers, data=payload)
# # data2 = json.loads(response2.text)
# # print(data2)

# while url:
#   if response.status_code==200:
#     response1 = requests.request("GET", url, headers=headers, data=payload)
#     data = list(json.loads(response.text))
#     next_data_link=(data['@odata.nextLink'])
#     next_data_link=url
#     new_data=data.extend(response['value'])
#     print(data)
#   else:
#     print(f"Request failed with status code {response.status_code}")
#     break
  

  #?$select=transc_object_id,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc"
#delta_api_url = 'https://airproducts-pilot.csod.com/services/api/x/dataexporter/api/objects/users_core?$filter=_last_touched_dt_utc ge cast('2022-08-01', Edm.DateTimeOffset)'

from datetime import datetime as dt

# get current date
# datetime_object = datetime.now()
# print(datetime_object.day)
# # print('Type :- ',type(datetime_object))

# # # my_string = '2019-10-31'

# # # # Create date object in given time format yyyy-mm-dd
# # my_date = datetime.strptime(str(datetime_object), "%Y-%m-%d")

# # # print(my_date)
# # # print('Type: ',type(my_date))

current_time = dt.now()
      
date_obj = current_time
print(type(date_obj))