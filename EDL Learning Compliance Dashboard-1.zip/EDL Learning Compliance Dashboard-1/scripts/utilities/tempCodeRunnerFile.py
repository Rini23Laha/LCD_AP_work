# response = requests.request("GET", url, headers=headers, data=payload)
# #print(response.text)
# data = json.loads(response.text)
# next_link=data['@odata.nextLink']
# print(type(next_link))