from botocore.exceptions import ClientError
from asyncio import constants
from datetime import datetime,timedelta
from dateutil.relativedelta import relativedelta
from time import sleep
import boto3
import pandas as pd
import base64
import json
import logging as logging
from time import sleep
import hmac
import requests
import urllib.parse
from configs import constants
from utilities import dynamodb_utils
from utilities import utils
if len(logging.getLogger().handlers) > 0:
        logging.getLogger().setLevel(logging.INFO)
else:
    logging.basicConfig(
        format='[%(levelname)s][%(filename)s] [%(funcName)s] [%(lineno)d] %(message)s', level=logging.INFO)

    

historical_s3_rawdata_path_format="s3://{bucket}/{prefix}{api_name}/year={year}/month={month}/day={day}/{table_name}/"
s3_rawdata_path_format="s3://{bucket}/{prefix}{api_name}/{table_name}/"
s3_rawdata_delta_path_format="s3://{bucket}/{prefix}{api_name}/{table_name}/"
s3_rawdata_path_prefix_format="{prefix}{api_name}/{table_name}/"
historical_s3_rawdata_path_prefix_format="{prefix}{api_name}/year={year}/month={month}/day={day}/{table_name}/"
delta_s3_rawdata_path_prefix_format="{prefix}{api_name}/year={year}/month={month}/day={day}/{table_name}/"

def call_api(method:str, url:str, params:list,body_json:str, timeout:int,headers:dict=None,json:str=None)-> requests.Response:
    if method.__eq__('GET'):
        response = requests.get(url=url, timeout=timeout,headers=headers)
    elif  method.__eq__('POST'):
        response = requests.post(url, data=body_json,json=json,timeout=timeout,headers=headers)
    else:
        raise RuntimeError("Please pass the valid method type Allowed Values:(GET/POST)")
    
    return response


def is_validate_response(response: requests.Response)->bool:
    if response.status_code==200:
        return True
    else: 
        return False



'''
Read the API Key from AWS secrets manager

'''
def get_secret(secret_name,region_name):
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client('secretsmanager',region_name=region_name)

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    return json.loads(secret)


def write_pd_to_local(dataframe:pd, file_path:str):
    logging.info(f" writing the files to file_path = {file_path} ")                  
    dataframe.to_parquet(file_path,engine='pyarrow',index=False)
    return dataframe  

def write_pd_delta_to_local(dataframe:pd, delta_file_path:str):
    logging.info(f" writing the files to file_path = {delta_file_path} ")                  
    dataframe.to_parquet(delta_file_path,engine='pyarrow',index=False)
    return dataframe 

def _last_touched_dt_utc (pd_dataframe,dynamo_client):
    
    startTime = ((datetime.now()+ timedelta(hours=8))- relativedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S")
    _last_touched_dt_utc = pd_dataframe[' _last_touched_dt_utc'].tolist()
    
    for  _last_touched_dt_utc in  _last_touched_dt_utc:
        #carnum = truck['carnum']
        try:
            response = dynamo_client.get_item(Key={' _last_touched_dt_utc':  _last_touched_dt_utc}, ConsistentRead=True)
           
        except ClientError as e:
            logging.info(e.response['Error']['Message'])
        else:
            if 'Item' not in response:
                print("New  _last_touched_dt_utc Added:", _last_touched_dt_utc)
                dynamo_client.put_item(Item= {' _last_touched_dt_utc':  _last_touched_dt_utc,'lastJobRun':  startTime,'runstatus': 'Not Started'})
            else:
                print("_last_touched_dt_utc Exists:",_last_touched_dt_utc)
                
                
                
                
def get_last_touched_dt_utc(self,args:dict):
        dynamo_client=dynamodb_utils.get_table_client(constants.checkpoint_table)
        is_historical_data=args['is_historical_data']
        if is_historical_data.lower().__eq__('false'):
           # starttime_dt= (dt.today().replace(hour=00,minute=00,second=00,microsecond=00))-timedelta(days=1,hours=8)
            attributes_to_get=['_last_touched_dt_utc']
            get_item_params={
                'Key':{
                    'api_name':args['api_name']
                },
                'ProjectionExpression':','.join(attributes_to_get)
            }
            response=dynamodb_utils.get_item(dynamotable=dynamo_client,pk_value_map=get_item_params)
            if 'item' in response:
             dynamo_client.put_item(Item= {'api_name': args['api_name'],'last_touched_dt_utc': _last_touched_dt_utc ,'runstatus': 'Not Started'})
             
            
            
def update_last_touched_dt_utc(dynamoclient,_last_touched_dt_utc, to_time):
        try:
            response = dynamoclient.update_item(
            Key={'_last_touched_dt_utc': _last_touched_dt_utc},
            UpdateExpression="set _last_touched_dt_utc = :s, runstatus= :s",
            ExpressionAttributeValues={
               ':s': _last_touched_dt_utc,
               ':s': 'Success',
            },
            ReturnValues="UPDATED_NEW"
        )
        except Exception as msg:
            print(f"Oops, could not update: {msg}")
        else:
            return response['Attributes']



def write_to_S3(s3_client,target_bucket:str,file_path:str,dest_s3_path_prefix:str,filename:str,is_historical_data:bool):   
    logging.info(f"Writing the files to s3 bucket {target_bucket} path: {dest_s3_path_prefix}")
    s3_client.upload_file(file_path, target_bucket, dest_s3_path_prefix +filename)
    
def write_delta_toS3(s3_client,delta_target_bucket:str,delta_file_path:str,dest_delta_s3_path_prefix:str,filename:str,is_historical_data:bool):   
    logging.info(f"Writing the files to s3 bucket {delta_target_bucket} path: {dest_delta_s3_path_prefix}")
    s3_client.upload_file(delta_file_path, delta_target_bucket, dest_delta_s3_path_prefix +filename)
    
def update_last_touched_dt_utc(self,args:dict):
        dynamo_client=dynamodb_utils.get_table_client(constants.checkpoint_table)
        is_historical_data=args['is_historical_data']
        if is_historical_data.lower().__eq__('false'):
            attributes_to_get=['_last_touched_dt_utc']
            get_item_params={
                'Key':{
                    'api_name':args['api_name']
                },
                'ProjectionExpression':','.join(attributes_to_get)
            }
            last_touched_date=dynamodb_utils.get_item(dynamotable=dynamo_client,pk_value_map=get_item_params)
            print(last_touched_date)
    
            print("start delta load process")
            delta_api_url='https://{{environment}}.csod.com/services/api/x/dataexporter/api/objects/transcript_core?$select=is_latest_reg_num,is_assigned,is_removed,transc_object_id,transc_user_id,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc?$filter=_last_touched_dt_utc ge {last_touched_date}'

def clean_folder(args,s3_resource,dest_s3_path_prefix:str):
    is_historical_data=args[is_historical_data]
    if is_historical_data.lower() == 'true':
      bucket = s3_resource.Bucket(args["raw_bucket"])
      parquet_file_list=utils.list_s3_objects(input_bucket=bucket,prefix=dest_s3_path_prefix) 
      utils.delete_files(bucket=bucket,file_list=parquet_file_list,s3_resource=s3_resource)




    