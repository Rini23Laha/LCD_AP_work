import logging
import boto3

dynamotable=None
def get_table_client(table_name:str):
    #if dynamotable is None:
    dynamotable=boto3.resource('dynamodb').Table(table_name)
    return dynamotable

def get_item(dynamotable,pk_value_map):
    response = dynamotable.get_item(**pk_value_map, ConsistentRead=True)
    return response
    
def put_item(dynamotable,pk_value_map):
    dynamotable.put_item(Item= pk_value_map)


def update_item(dynamotable,key:dict, update_expression:str,expression_values:dict):
        try:
            response = dynamotable.update_item(
            Key=key,
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_values   
        )
        except Exception as msg:
            logging.error(f"Oops, could not update: {str(msg)}")
            raise RuntimeError(f"Failed to update the dynamo db")
    