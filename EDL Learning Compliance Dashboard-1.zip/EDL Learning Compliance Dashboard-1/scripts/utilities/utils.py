'''
    title : s3_utils.py
    description : contains the various utils methods
    functionality : Please refer each functions defined below
    version : 1.0
    usage : invoked by transformers and data load script
    python_version : 3.0
'''
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timedelta
import logging
import json
import traceback


boto_client=None
s3_resource=None
def get_s3_resource():
    global s3_resource
    if s3_resource is None:
       s3_resource=boto3.resource('s3')
    return s3_resource

def get_s3_client():
    global boto_client
    if boto_client is None:
       boto_client=boto3.client('s3')
    return boto_client

def list_s3_objects(input_bucket, prefix=None):
    """
    Lists the objects in a bucket, optionally filtered by a prefix.

    :param bucket: The bucket to query. This is a Boto3 Bucket resource.
    :param prefix: When specified, only objects that start with this prefix are listed.
    :return: boolean whether files are present of not
    """
    logging.info(f"list the files under prefix - {prefix}")
    try:
        if not prefix:
            objects = list(input_bucket.objects.all())
        else:
            objects = list(input_bucket.objects.filter(
                Prefix=prefix, Delimiter='/'))
           
            if len(objects):
                return objects
    except ClientError:
        print(
            "ERROR: Couldn't get objects for bucket '%s'.", input_bucket.name)

# Archive the .json files in the archive folder after the json to parquet conversion is performed


def archive_output_file(s3_resource, file_list, bucket):
    '''
    moves the files under todays date folder in s3 - used to archive the parquet files in processed layer
    '''
    date_str = datetime.now().strftime("%Y%m%d")
    for file in file_list:
        if file.key != '':
            path = file.key.rsplit(
                '/', 2)[0] + "/"+date_str+"/" + file.key.rsplit('/', 2)[1]+"/" + file.key.rsplit('/', 1)[1]
            print(path)
            copy_source = {
                'Bucket': bucket.name,
                'Key': file.key
            }
            s3_resource.meta.client.copy(copy_source, bucket.name, path)


def move_input_file(s3_resource:str, file_list: list, bucket, dest_path:str):
    '''
    Moves the file in the raw layer according to the date present in the file name - used to archive the raw files
    '''   
    for file in file_list:
        if file.key != '':
            copy_source = {
                'Bucket': bucket.name,
                'Key': file.key
            }
            name=file.key.rsplit('/', 1)[1]
            path_format=dest_path+"year={year}/month={month}/day={day}/"
            fromdate=datetime.now()
            path=path_format.format(year=fromdate.year,month=fromdate.month,day=fromdate.day)
            complete_path= path+file.key.rsplit('/', 1)[1]
            logging.info(f"moving to file {name} to path {complete_path}" )
            s3_resource.meta.client.copy(copy_source, bucket.name, complete_path)


def delete_files(s3_resource, file_list, bucket):
    # Delete the .json files in the source folder after the json to parquet conversion is performed.
    if file_list !=None and len(file_list)>0:
        try:
            for file in file_list:
                if file.key != '' and bucket != '':
                    s3_resource.meta.client.delete_object(
                        Bucket=bucket.name, Key=file.key)
        except ClientError as ex:
            print("Exception caused while deleting the input file")
            raise ex
    
# def move_and_delete_fn(s3_resource, bucket,dest_base_path:str, file_list=None):
#     logging.info("archiving the file %s", file_list)
#     path_format=dest_base_path+"year={year}/month={month}/day={day}"
#     if file_list is None:
#         pass
#     else:
        
#             move_input_file(s3_resource, file_list, bucket, path_format)
#             delete_files(s3_resource, file_list, bucket)

def move_and_delete(s3_resource, bucket,dest_path:str, file_list=None):
    logging.info("archiving the file %s", file_list)
    logging.info(f"moving the files to bucket {bucket} dest_path: {dest_path}")
    move_input_file(s3_resource, file_list, bucket, dest_path)
    delete_files(s3_resource, file_list, bucket)



def delete_output_paths(s3resource, list_of_paths):
    
    '''
    Deletes the parquet files for the given path
    This deletion is required in case of 
    1. Rerunning the pipeline for a given date
    '''
    for path in list_of_paths:
        if path != '' or path != '.':
            output_file_bucket_name = path.split("/")[2]
            bucket = s3resource.Bucket(output_file_bucket_name)
            output_files_prefix = path.partition(
                "/")[2].split('/', 2)[-1]
            previous_output_file_list = list_s3_objects(
                input_bucket=bucket, prefix=output_files_prefix)
            if previous_output_file_list is not None:
                delete_files(s3_resource=s3resource, bucket=bucket,
                                  file_list=previous_output_file_list)




def handle_service_now_ticket_generation(exception, job_name, sns_arn, account_id, region, run_id, servicenow_lambdafn, dynamo_db_table_name):
    try:
        dynamodb = boto3.resource('dynamodb').Table(dynamo_db_table_name)
        response = dynamodb.get_item(
            Key={'exception': exception}, ConsistentRead=True)
        logging.info(f"Response of getting item from dynamodb - {response}")
    except ClientError as ce:
        logging.info(ce.response['Error']['Message'])
    else:
        if 'Item' in response:
            updated_time_dt =datetime.strptime(response['Item']['updatedtime'], "%Y/%m/%d %H:%M:%S")
            logging.info(
                f"Time difference between the service now ticket raised for same exception - {response}")
        else:
            updated_time_dt = datetime.strptime(
                "2023/01/20 00:00:00", "%Y/%m/%d %H:%M:%S")
        time_diff = datetime.utcnow() - updated_time_dt
        if 'Item' not in response or time_diff.days:
            dt_utc_str = datetime.utcnow().strftime("%Y/%m/%d %H:%M:%S")

            message = json.dumps({'default': json.dumps(
                
                {
                    'AlarmName': job_name,
                    'AlarmDescription': "Failure on lcd Glue Job. Job name: " + job_name + ", RunID: " + run_id + "\n##ProductId(23381)\n##Impact(2)",
                    'AWSAccountId': account_id,
                    'NewStateValue': 'Failed',
                    'NewStateReason': exception,
                    'StateChangeTime': dt_utc_str,
                    'Region': region,
                    'AlarmArn': job_name,
                    'OldStateValue': "NA"
                })})

            dynamodb.put_item(
                Item={'exception': exception, 'updatedtime': dt_utc_str})

            client = boto3.client('sns')
            response = client.publish(
                TargetArn=sns_arn,
                Message=message,
                MessageStructure='json'
            )
            logging.info(f"Response of sns publish - {response}")

            sn_event = json.dumps({'default': json.dumps(
                {
                    'AlarmName': job_name,
                    'AlarmDescription': "lcd: Job name: " + job_name + ", RunID: " + run_id + "\n##ProductId(23381)\n##Impact(2)",
                    'AWSAccountId': account_id,
                    'NewStateValue': 'Failed',
                    'NewStateReason': exception,
                    'StateChangeTime': dt_utc_str,
                    'Region': region,
                    'AlarmArn': job_name,
                    'OldStateValue': "NA"
                })})

           
            if account_id.__eq__("930435624388"):
            # if account_id.__eq__("772631637424"):
                logging.info("creating service now ticket")                
                sn_response = client.publish(
                    TargetArn=servicenow_lambdafn,
                    Message=sn_event,
                    MessageStructure='json'
                )
                logging.info(f"Response of service now sns publish - {sn_response}")
            



def notify_sns(message:str, sns_arn:str):
    client = boto3.client('sns')    
    response = client.publish(
        TargetArn=sns_arn,
        Message=message,
        MessageStructure='json'
    )
    logging.info(f"{response}")
    logging.info(f"reported to exception to sns {sns_arn}")


