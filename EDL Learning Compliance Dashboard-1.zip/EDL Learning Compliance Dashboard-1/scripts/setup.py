from setuptools import find_packages, setup

setup(
    name="commons",
    version="0.1",
    packages=find_packages(include=['extract','extractor','configs','utilities','commons','transform','dq','extract_interface'])
    
) 