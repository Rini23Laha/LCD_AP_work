rs_transcript_status_local_core="transcript_status_local_core"
rs_transcript_status_local_core_status="transcript_status_local_core_status"
table_field_mapping={
    rs_transcript_status_local_core:[
        ("culture_id","long","culture_id","long"),
        ("is_default","Boolean","is_default","Boolean"),
        ("status_id","long","status_id","long"),
        ("status_name","string","status_name","string"),
        ("_last_touched_dt_utc","timestamp","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}
