rs_curriculum_structure_core="curriculum_structure_core"
rs_curriculum_structure_core_status="curriculum_structure_core_status"
table_field_mapping={
    rs_curriculum_structure_core:[
        ("curriculum_object_id","string","curriculum_object_id","string"),
        ("parent_object_id","string","parent_object_id","string"),
        ("object_id","string","object_id","string"),
        ("_last_touched_dt_utc","timestamp","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}

