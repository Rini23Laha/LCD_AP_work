rs_training_cf_core="training_cf_core"
rs_training_cf_core_status="training_cf_core_status"
table_field_mapping={
    rs_training_cf_core:[
        ("object_id","string","object_id","string"),
        ("field_8","string","field_8","string"),
        ("field_5","string","field_5","string"),
        ("field_10","boolean","field_10","boolean"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}
