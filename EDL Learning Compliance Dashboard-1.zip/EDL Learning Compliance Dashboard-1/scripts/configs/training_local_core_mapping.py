rs_training_local_core="training_local_core"
rs_training_local_core_status="training_local_core_status"
table_field_mapping={
    rs_training_local_core:[
        ("object_id","string","object_id","string"),
        ("culture_id","long","culture_id","long"),
        ("title","string","title","string"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}
