rs_user_ou_core="user_ou_core"
rs_user_ou_core_status="user_ou_core_status"
table_field_mapping={
    rs_user_ou_core:[
        ("user_id","long","user_id","long"),
        ("ou_id","long","ou_id","long"),
        ("ou_type_id","long","ou_type_id","integer"),
        ("status_id","double","status_id","integer"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}