rs_ou_core="ou_core"
rs_ou_core_status="ou_core_status"
table_field_mapping={
    rs_ou_core:[
        ("title","string","title","string"),
        ("ou_id","long","ou_id","long"),
        ("parent_id","integer","parent_id","integer"),
        ("type_id","integer","type_id","integer"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}
