rs_training_core="training_core"
rs_training_core_status="training_core_status"
table_field_mapping={
    rs_training_core:[
        ("lo_active","string","lo_active","string"),
        ("lo_hours","double","lo_hours","double"),
        ("object_id","string","object_id","string"),
        ("related_lo_id","string","related_lo_id","string"),
        ("lo_object_type","string","lo_object_type","string"),
        ("lo_status_type","string","lo_status_type","string"),
         ("lo_language_id","long","lo_language_id","long"),
          ("lo_location_id","long","lo_location_id","long"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}


