rs_transcript_core="transcript_core"
rs_transcript_core_status="transcript_core_status"
table_field_mapping={
    rs_transcript_core:[
        ("transc_object_id","string","transc_object_id","string"),
        ("reg_num","integer","reg_num","integer"),
        ("transc_user_id","integer","transc_user_id","integer"),
        ("is_latest_reg_num","boolean","is_latest_reg_num","boolean"),
        ("is_assigned","boolean","is_assigned","boolean"),
        ("is_removed","boolean","is_removed","boolean"),
        ("user_lo_assigned_dt","string","user_lo_assigned_dt","string"),
        ("user_lo_comp_dt","string","user_lo_comp_dt","string"),
        ("user_lo_min_due_date","string","user_lo_min_due_date","string"),
        ("user_lo_status_id","long","user_lo_status_id","long"),
        ("user_lo_start_dt","string","user_lo_start_dt","string"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string"),
        ("user_lo_assigned_dt_utc","string","user_lo_assigned_dt_utc","timestamp"),
        ("user_lo_comp_dt_utc","string","user_lo_comp_dt_utc","timestamp"),
        ("user_lo_min_due_date_utc","string","user_lo_min_due_date_utc","timestamp"),
        ("user_lo_start_dt_utc","string","user_lo_start_dt_utc","timestamp")
    
    ]
}











