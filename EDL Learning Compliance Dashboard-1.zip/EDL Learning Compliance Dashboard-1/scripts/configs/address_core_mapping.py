rs_address_core="address_core"
rs_address_core_status="address_core_status"
table_field_mapping={
    rs_address_core:[
        ("city","string","city","string"),
        ("country_code","string","country_code","string"),
        ("address_id","integer","address_id","integer"),
        ("_last_touched_dt_utc","string","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}





