import enum


historical_s3_raw_data_path_format="s3://{bucket}/{prefix}{api_name}/{table_name}/year={year}/month={month}/day={day}/"
#delta_s3_raw_data_path_format="s3://{bucket}/{prefix}{api_name}/{table_name}/year={year}/month={month}/day={day}/"
s3_raw_data_path_format="s3://{bucket}/{prefix}{api_name}/{table_name}/"
s3_raw_data_path_prefix_format="{prefix}{api_name}/"
historical_s3_rawdata_path_prefix_format="{prefix}{api_name}/{table_name}/year={year}/month={month}/day={day}/"
path_only_prefix="{prefix}{api_name}/{table_name}/"
s3_processed_data_path_format="s3://{bucket}/{prefix}{api_name}/{table_name}/year={year}/month={month}/day={day}/"
Expires = "86400"
#host = "airproducts-pilot.csod.com"
local_file_path="/tmp/"
timeout=60
filename_format="{api}-{to_dt}.parquet"
checkpoint_table='lcd_data_extraction_checkpoint'
request_retry_count=2
s3_raw_data_archive_path_prefix_format="{prefix}{api_name}/{table_name}/"
# s3_raw_data_path_prefix_format_with_s3=
URL_FORMAT = "{base_url}/{end_point}?{parameters}{condition}"
API_MAX_RETRY=2
API_TIMEOUT=30

from enum import Enum
class HttpMethod(Enum):
    GET="GET"
    POST="POST"
