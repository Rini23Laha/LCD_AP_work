'''
    title : mappings.py
    description : contains the mapping of api:table, table: unique_fields mapping to identify the duplicates and redishift configs
    functionality : has the various mappings mentioned in description
    version : 1.0
    usage : invoked by transformers and data load script
    python_version : 3.0
'''
from configs import transcript_core_mapping
from configs import ou_core_mapping
from configs import user_ou_core_mapping
from configs import training_cf_core_mapping
from configs import training_local_core_mapping
from configs import training_core_mapping
from configs import transcript_status_local_core_mapping
from configs import culture_core_mapping
from configs import curriculum_structure_core_mapping
from configs import users_core_mapping
from configs import address_core_mapping

redshift_database_name = "lcd"
redshift_schema_name = "source"
# input path mapping
glue_redshift_connection_name = "ap_glue_lcd_redshift_connection"

api_table_mapping = {
    "transcript_core": transcript_core_mapping.table_field_mapping,
    "ou_core": ou_core_mapping.table_field_mapping,
    "user_ou_core":user_ou_core_mapping.table_field_mapping,
    "training_cf_core":training_cf_core_mapping.table_field_mapping,
    "training_local_core":training_local_core_mapping.table_field_mapping,
    "training_core":training_core_mapping.table_field_mapping,
    "transcript_status_local_core":transcript_status_local_core_mapping.table_field_mapping,
    "culture_core":culture_core_mapping.table_field_mapping,
    "curriculum_structure_core":curriculum_structure_core_mapping.table_field_mapping,
    "users_core":users_core_mapping.table_field_mapping,
    "address_core":address_core_mapping.table_field_mapping
}
table_unique_field = {
    transcript_core_mapping.rs_transcript_core : f"stage_{transcript_core_mapping.rs_transcript_core}.transc_object_id = {transcript_core_mapping.rs_transcript_core}.transc_object_id and stage_{transcript_core_mapping.rs_transcript_core}.transc_user_id = {transcript_core_mapping.rs_transcript_core}.transc_user_id and stage_{transcript_core_mapping.rs_transcript_core}.reg_num = {transcript_core_mapping.rs_transcript_core}.reg_num",
    ou_core_mapping.rs_ou_core : f"stage_{ou_core_mapping.rs_ou_core}.ou_id = {ou_core_mapping.rs_ou_core}.ou_id",
    user_ou_core_mapping.rs_user_ou_core:f"stage_{user_ou_core_mapping.rs_user_ou_core}.user_id={user_ou_core_mapping.rs_user_ou_core}.user_id and stage_{user_ou_core_mapping.rs_user_ou_core}.ou_type_id={user_ou_core_mapping.rs_user_ou_core}.ou_type_id",
    training_cf_core_mapping.rs_training_cf_core:f"stage_{training_cf_core_mapping.rs_training_cf_core}.object_id={training_cf_core_mapping.rs_training_cf_core}.object_id",
    training_local_core_mapping.rs_training_local_core:f"stage_{training_local_core_mapping.rs_training_local_core}.object_id={training_local_core_mapping.rs_training_local_core}.object_id and stage_{training_local_core_mapping.rs_training_local_core}.culture_id={training_local_core_mapping.rs_training_local_core}.culture_id",
    training_core_mapping.rs_training_core:f"stage_{training_core_mapping.rs_training_core}.object_id={training_core_mapping.rs_training_core}.object_id",
    transcript_status_local_core_mapping.rs_transcript_status_local_core:f"stage_{transcript_status_local_core_mapping.rs_transcript_status_local_core}.status_id={transcript_status_local_core_mapping.rs_transcript_status_local_core}.status_id and stage_{transcript_status_local_core_mapping.rs_transcript_status_local_core}.culture_id={transcript_status_local_core_mapping.rs_transcript_status_local_core}.culture_id",
    culture_core_mapping.rs_culture_core:f"stage_{culture_core_mapping.rs_culture_core}.culture_id={culture_core_mapping.rs_culture_core}.culture_id",
    curriculum_structure_core_mapping.rs_curriculum_structure_core:f"stage_{curriculum_structure_core_mapping.rs_curriculum_structure_core}.curriculum_object_id={curriculum_structure_core_mapping.rs_curriculum_structure_core}.curriculum_object_id and stage_{curriculum_structure_core_mapping.rs_curriculum_structure_core}.object_id={curriculum_structure_core_mapping.rs_curriculum_structure_core}.object_id and stage_{curriculum_structure_core_mapping.rs_curriculum_structure_core}.parent_object_id={curriculum_structure_core_mapping.rs_curriculum_structure_core}.parent_object_id",
    users_core_mapping.rs_users_core:f"stage_{users_core_mapping.rs_users_core}.user_id={users_core_mapping.rs_users_core}.user_id",
    address_core_mapping.rs_address_core:f"stage_{address_core_mapping.rs_address_core}.address_id={address_core_mapping.rs_address_core}.address_id"
}

