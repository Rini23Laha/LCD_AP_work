rs_culture_core="culture_core"
rs_culture_core_status="culture_core_status"
table_field_mapping={
    rs_culture_core:[
        ("culture_id","long","culture_id","long"),
        ("culture_name","string","culture_name","string"),
        ("descr","string","descr","string"),
        ("_last_touched_dt_utc","timestamp","_last_touched_dt_utc","timestamp"),
        ("api_name","string","api_name","string"),
        ("file_name","string","file_name","string")
    
    ]
}

