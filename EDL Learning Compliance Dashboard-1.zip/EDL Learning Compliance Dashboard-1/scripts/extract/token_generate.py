# import requests
# import time
# import json
# import certifi


# def generate_token(api_url, clientId, clientSecret):
# # Make a POST request to the API to obtain the access token
#     payload = {"clientId": clientId,
#                 "clientSecret": clientSecret,
#                 "grantType": "client_credentials",
#                 "scope": "all"
#             }
#     headers = {
#                 'Content-Type': 'application/json',
#                 'cache-control': 'no-cache'
#             }
#     token_response = requests.post(api_url, headers=headers, json=payload,verify=False)

#             # Check the token_response status
#     if token_response.status_code == 200:
#                 # Extract the access token from the token_response
#                 data = token_response.json()
#                 access_token = data["access_token"]
#                 #print('access_token:', access_token)
#                 #return access_token
#     else:
#                 # Handle the error if the request fails
#                 print(f"Failed to get access token. Status code: {token_response.status_code}")
#                 return None

# api_url = "https://airproducts-pilot.csod.com/services/api/oauth2/token"
# clientId = "4qbqr4gf113q"
# clientSecret = "a209bab5bc5cc3f9841e86f76e9d49f133e7582557be45b7565bf7fbcb80c543"
# access_token = generate_token(api_url, clientId, clientSecret)
# #print("access_token:", access_token)