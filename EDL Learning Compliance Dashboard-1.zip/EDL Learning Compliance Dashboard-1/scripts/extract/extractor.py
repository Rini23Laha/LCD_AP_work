from abc import abstractmethod



class extractor:
    @abstractmethod
    def extract(self,args:dict): raise NotImplementedError
