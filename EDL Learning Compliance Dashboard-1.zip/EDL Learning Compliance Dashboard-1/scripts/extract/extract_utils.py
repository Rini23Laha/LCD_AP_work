import logging
from time import sleep
import requests
import json
from configs import constants
import pandas as pd
from awsglue.utils import getResolvedOptions

def update_checkpoint(dynamoclient,carnum, to_time):
        try:
            response = dynamoclient.update_item(
            Key={'carnum': carnum},
            UpdateExpression="set lastJobRun = :l, runstatus= :s",
            ExpressionAttributeValues={
               ':l': str(to_time),
               ':s': 'Success',
            },
            ReturnValues="UPDATED_NEW"
        )
        except Exception as msg:
            print(f"Oops, could not update: {msg}")
        else:
            return response['Attributes']

def call_api(method:str, url:str, body_json:str,headers:dict=None,json_str:str=None)-> requests.Response:
    retry_count=0
    logging.info("URL: {%s}, header= {%s}",url,headers)
    while True:
        try:
            if method.__eq__('GET'):
                response = requests.get(url=url, timeout=constants.API_TIMEOUT,headers=headers)
            elif  method.__eq__('POST'):
                response = requests.post(url, data=body_json,json=json_str,timeout=constants.API_TIMEOUT,headers=headers)
            else:
                raise RuntimeError("Please pass the valid methos type Allowed Values:(GET/POST)")
            if response.status_code!=200:
                raise RuntimeError(str(response))
            return response
            
        except Exception as e:
            if retry_count> constants.API_MAX_RETRY:
                logging.error("url - {url}, headers - {headers}")
                logging.error(str(e), exc_info=True)
                logging.error("API call failed event after {constants.API_MAX_RETRY}")
                break
            else:
                 logging.error(str(e), exc_info=True)
                 retry_count+=1
                 sleep(60*retry_count)
                 continue
        
       

'''
This  method extracts the data by calling the APIs
'''
def extract_data(method:str, url:str,body_json:str=None,headers:dict=None,json_str:str=None, is_historical:bool=False):
    list_of_records=[]
    count=0
    while True: 
        api_response=call_api(method, url, body_json,headers,json_str)
        count=count+1
        records=json.loads(api_response.text)      
        list_of_records.extend(records.get('value',[]))
        next_page=records.get('@odata.nextLink') 
        url=next_page
        logging.info("next page link - {%s}",next_page) 
        if count > 100:
            sleep(60)
            logging.info("Sleeping for 60 sec")
            count=0    
        if not next_page: 
            break
    return list_of_records


def is_validate_response(response: requests.Response)->bool:
    if response.status_code==200:
        return True
    else: 
        return False




def write_pd_to_local(dataframe:pd, file_path:str):
    logging.info(f" writing the files to file_path = {file_path} ")                  
    dataframe.to_parquet(file_path,engine='pyarrow',index=False)
    return dataframe  

def write_to_S3(s3_client,target_bucket:str,file_path:str,dest_s3_path_prefix:str,filename:str,is_historical_data:bool):   
    logging.info(f"Writing the files to s3 bucket {target_bucket} path: {dest_s3_path_prefix}")
    s3_client.upload_file(file_path, target_bucket, dest_s3_path_prefix +filename)