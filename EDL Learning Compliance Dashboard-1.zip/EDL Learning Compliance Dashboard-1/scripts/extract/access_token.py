
import logging
import json
from configs import constants
from extract import extract_utils

ENDPOINT_URL = "/services/api/oauth2/token"
HEADERS = {
            'Content-Type': 'application/json',
            'cache-control': 'no-cache'
        }
'''
This method makes API call to get access tokens
'''
def get_auth_token(args:dict,clientId:str, clientSecret:str):
    BASE_URL=args['lcd_api_host']
    if BASE_URL.endswith('/'):
      BASE_URL= BASE_URL[:-1]
    API_URL=BASE_URL+ENDPOINT_URL
    payload = json.dumps({"clientId": clientId,
                "clientSecret": clientSecret,
                "grantType": "client_credentials",
                "scope": "all"
            })
    logging.info("api_url {api_url}")
    token_response = extract_utils.call_api(method=constants.HttpMethod.POST.value, url=API_URL, headers=HEADERS, body_json=payload)   
    auth_token_response = token_response.json()
    logging.info("token_response {token_response}")
    logging.info("token_response {%s}",token_response)
    # if extract_utils.is_validate_response(auth_token_response):
    #     access_token = auth_token_response["access_token"]
    # else:
    #      raise RuntimeError("Failed to get access token from the API {api_url}")
    
    return auth_token_response.get('access_token')