import os
from extract import extractor
os.environ["SPARK_VERSION"] = "3.1"
'''
above 2 lines should placed in first row - used in data quality
'''
import boto3
from extract import transcript_core
from extract import ou_core
from extract import user_ou_core
from extract import training_cf_core
from extract import training_local_core
from extract import training_core
from extract import transcript_status_local_core
from extract import culture_core
from extract import curriculum_structure_core
from extract import users_core
from extract import address_core
from utilities import utils
from datetime import datetime

import sys
import logging
from configs import constants
from awsglue.utils import getResolvedOptions
"""
This is entry point for the extraction code, delegates actaul extraction work to respective API extractor

Raises:
Runtime exception incase of any errors creates the SNS notification and service now ticket

"""
if len(logging.getLogger().handlers) > 0:
    logging.getLogger().setLevel(logging.INFO)
else:
    logging.basicConfig(
        format='[%(levelname)s][%(filename)s] [%(funcName)s] [%(lineno)d] %(message)s', level=logging.INFO)

if '--WORKFLOW_NAME' in sys.argv and '--WORKFLOW_RUN_ID' in sys.argv:
    args = getResolvedOptions(sys.argv,
                                ['raw_bucket',
                                'processed_bucket',
                                'lcd_api_host',                            
                                'path_prefix',
                                'secret_name',
                                'region_name',                       
                                'no_concurrent_req',                           
                                'WORKFLOW_NAME',
                                'WORKFLOW_RUN_ID',
                                'JOB_NAME',
                                'sns_arn',
                                'servicenow_sns_topic',
                                'account_id'
                                
                            
                                ])
    glue_client = boto3.client('glue', region_name=args['region_name'])
    workflow_args=glue_client.get_workflow_run_properties( Name=args['WORKFLOW_NAME'], RunId=args['WORKFLOW_RUN_ID'])["RunProperties"]
    constants.BASE_URL=args['lcd_api_host']
    # print(workflow_args)
    
    if 'aws:eventIds' in workflow_args :
       workflow_args['is_historical_data'] = 'False'
       workflow_args['is_full_load_'] = 'False'
       args['is_historical_data'] = 'False'
       args['is_full_load_']='False'
       args['api_name'] = workflow_args['api_name']
    elif  'start_date' in workflow_args and 'end_date' and 'is_full_load_' in workflow_args :
        
        workflow_args['is_historical_data'] = 'True'  
        workflow_args['is_full_load_'] = 'False' 
        args['is_full_load_']='False'
        args['is_historical_data']='True'
        args['start_date'] = workflow_args['start_date']
        args['end_date'] = workflow_args['end_date']
        args['api_name'] = workflow_args['api_name']
        print("historical",args['start_date'])
        print("historical",args['end_date'])
    
    else:
        workflow_args['is_historical_data'] = 'True'
        workflow_args['is_full_load_'] = 'True'
        args['is_historical_data'] = 'True'
        args['is_full_load_']='True'
        args['api_name'] = workflow_args['api_name']
        
    logging.info(args)     
else:
    logging.error("Job should trigger from the workflow id")
    raise Exception("GlueJob Not Started by the workflow, please trigger the job from workflow")

#is_historical_data=args['is_historical_data']

def extractor_factory(api) -> extractor:
    """
    This method as return the object of transformer class got the given API name  
    """
    api_objects = {
        "transcript_core": transcript_core.transcript_core(),
        "ou_core":ou_core.ou_core(),
        "user_ou_core":user_ou_core.user_ou_core(),
        "training_cf_core":training_cf_core.training_cf_core(),
        "training_local_core":training_local_core.training_local_core(),
        "training_core":training_core.training_core(),
        "transcript_status_local_core":transcript_status_local_core.transcript_status_local_core(),
        "culture_core":culture_core.culture_core(),
        "curriculum_structure_core":curriculum_structure_core.curriculum_structure_core(),
        "users_core":users_core.users_core(),
        "address_core":address_core.address_core()
        }
    return api_objects.get(api)
try:
    logging.info(f"starting the transformation {args}")
    extractor_factory(workflow_args['api_name']).extract(args=args)
    
except AttributeError as e:  
    raise RuntimeError(str(e))
except Exception as e:
    logging.error(f"data extraction failed - {str(e)}",exc_info=True)
    logging.error(f"job args: {args}")
    utils.handle_service_now_ticket_generation(exception = str(e), job_name = args.get("JOB_NAME"), sns_arn = args.get("sns_arn"), account_id = args.get("account_id"), region = args.get("region_name"), run_id = args.get("WORKFLOW_RUN_ID"), servicenow_lambdafn = args.get("servicenow_sns_topic"),dynamo_db_table_name='lcd_exceptions')
    
    raise e
    os._exit(status=1)