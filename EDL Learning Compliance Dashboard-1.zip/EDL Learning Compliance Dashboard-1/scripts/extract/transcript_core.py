

from extract import extractor
from datetime import datetime as dt
import pandas as pd
from configs import constants
from extract import extract_utils
from utilities import secrets_manager
from utilities import dynamodb_utils
from utilities import utils
import logging
from extract import access_token
### general declarations for api_call #############
s3_client = utils.get_s3_client()
s3_resource = utils.get_s3_resource()
api ="transcript_core"
# primary_key=f"transc_object_id,reg_num,transc_user_id"
# columns=f"transc_object_id,reg_num,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc"
filename_format="{api_name}.parquet"
END_POINT="services/api/x/dataexporter/api/objects/transcript_core"
PARAMETERS= "$select=transc_object_id,reg_num,transc_user_id,is_latest_reg_num,is_assigned,is_removed,user_lo_assigned_dt,user_lo_comp_dt,user_lo_min_due_date,user_lo_status_id,user_lo_start_dt,_last_touched_dt_utc"
#CONDITION="&$filter=_last_touched_dt_utc gt cast('2023-08-01', Edm.DateTimeOffset) and _last_touched_dt_utc lt cast('2023-08-15', Edm.DateTimeOffset)"
CONDITION=''



class transcript_core(extractor.extractor):
  '''
    Function extracts the data from transcript core
  '''
  def extract(self, args: dict):
    args['api_name']=api
    is_historical_data=args['is_historical_data']
    is_full_load_=args['is_full_load_']
    BASE_URL=args['lcd_api_host']
    if BASE_URL.endswith('/'):
      BASE_URL= BASE_URL[:-1]
   
    if is_historical_data.lower() == 'true' and is_full_load_.lower()== 'true':
      CONDITION=''
      url = constants.URL_FORMAT.format(base_url=BASE_URL,end_point=END_POINT,parameters=PARAMETERS,condition=CONDITION)
      today_date_obj = dt.now()
    elif  is_historical_data.lower() == 'true' and is_full_load_.lower()== 'false':
          start_date=args['start_date']
          print("args['start_date']",start_date)
      
          end_date=args['end_date']
          print("args['end_date']",end_date)
          CONDITION=f"&$filter=_last_touched_dt_utc gt cast('{start_date}', Edm.DateTimeOffset) and _last_touched_dt_utc lt cast('{end_date}', Edm.DateTimeOffset)"
          url = constants.URL_FORMAT.format(base_url=BASE_URL,end_point=END_POINT,parameters=PARAMETERS,condition=CONDITION)
          print(url)
          today_date_obj = dt.now()
       
    else:
        dynamo_client=dynamodb_utils.get_table_client(constants.checkpoint_table)   
        attributes_to_get=['last_touched_dt_utc']
        get_item_params={
              'Key':{
                  'api_name':args['api_name']
              },
              'ProjectionExpression':','.join(attributes_to_get)
          }
        previous_extraction_row=dynamodb_utils.get_item(dynamotable=dynamo_client,pk_value_map=get_item_params)
        item=previous_extraction_row.get('Item',{})    
        previous_last_touched_dt_utc=(item.get('last_touched_dt_utc'))      
        filter_condition = f"&$filter=_last_touched_dt_utc gt cast('{previous_last_touched_dt_utc}', Edm.DateTimeOffset)"
        url = constants.URL_FORMAT.format(base_url=BASE_URL,end_point=END_POINT,parameters=PARAMETERS,condition=filter_condition)
        logging.info("delta url - %s",url)
        today_date_obj = dt.now()
    
    api_secret =secrets_manager.get_secret(args['secret_name'],args['region_name']) 
    token=access_token.get_auth_token(args=args,clientId=api_secret.get('access_id'),clientSecret=api_secret.get('access_secret'))
    headers={
       'Content-Type': 'application/json',
       'cache-control': 'no-cache',
       'prefer': 'odata.maxpagesize=10000',
       'Authorization': f'Bearer {token}'
    }        
    records=extract_utils.extract_data(constants.HttpMethod.GET,url=url,headers=headers)
    logging.info("Number of records {%d}",len(records))
    pd_data=pd.DataFrame(records)
    if is_historical_data.lower() == 'true':
      
      previous_last_touched_dt_utc=pd_data['_last_touched_dt_utc'].min() 
    latest_last_touched_dt_utc=pd_data['_last_touched_dt_utc'].max()
    # filename=constants.filename_format.format(api=api, from_dt=previous_last_touched_dt_utc.replace(':','_').split('.')[0].replace('-','_'), to_dt=latest_last_touched_dt_utc.replace(':','_').split('.')[0].replace('-','_'))
    filename=constants.filename_format.format(api=api,to_dt=latest_last_touched_dt_utc.replace(':','_').split('.')[0].replace('-','_'))
    file=constants.local_file_path+filename
    pd_data['api_name'] = api
    pd_data['file_name'] =   filename
    logging.info("columns---> {%s}",pd_data.columns)      
    pd_data.to_parquet('pd_data.parquet', engine='pyarrow',index='False')
    key={'api_name': api}
    update_expression="set last_touched_dt_utc = :l, runstatus= :s"
    ExpressionAttributeValues={
                ':l':latest_last_touched_dt_utc,
                ':s': 'Success',
                }
    dynamodb_utils.update_item(dynamotable=dynamodb_utils.get_table_client(constants.checkpoint_table),key=key,expression_values=ExpressionAttributeValues,update_expression=update_expression)
  
    # write output to s3 path
    if is_historical_data.lower() == 'false' and is_full_load_.lower()== 'false':
      dest_s3_path_prefix=constants.s3_raw_data_archive_path_prefix_format.format(prefix=args['path_prefix'],api_name=api,table_name=api)
      print(dest_s3_path_prefix)
    
    elif  is_historical_data.lower() == 'true' and is_full_load_.lower()== 'false':
      dest_s3_path_prefix=constants.s3_raw_data_archive_path_prefix_format.format(prefix=args['path_prefix'],api_name=api,table_name=api)
      print(dest_s3_path_prefix)
      
    else:
      dest_s3_path_prefix=constants.historical_s3_rawdata_path_prefix_format.format(prefix=args['path_prefix'],api_name=api,table_name=api,year=today_date_obj.year,month=today_date_obj.month,day=today_date_obj.day)
      bucket = s3_resource.Bucket(args['raw_bucket'])
      print('raw_Bucket',bucket)
      parquet_file_list=utils.list_s3_objects(input_bucket=bucket,prefix=dest_s3_path_prefix)
      utils.delete_files(bucket=bucket,file_list=parquet_file_list,s3_resource=s3_resource)

    extract_utils.write_pd_to_local(dataframe=pd_data,file_path=file)
    extract_utils.write_to_S3(s3_client=s3_client,target_bucket=args['raw_bucket'],file_path=file,dest_s3_path_prefix=dest_s3_path_prefix,filename=filename,is_historical_data=is_historical_data)
    ####updating dynamo_db####
    if is_historical_data.lower() == 'false':
      key={'api_name': api}
      update_expression="set last_touched_dt_utc = :l, runstatus= :s"
      ExpressionAttributeValues={
                ':l':latest_last_touched_dt_utc,
                ':s': 'Success',
                }
      
      dynamodb_utils.update_item(dynamotable=dynamodb_utils.get_table_client(constants.checkpoint_table),key=key,expression_values=ExpressionAttributeValues,update_expression=update_expression)
      logging.info(f"updating the checkpoint {latest_last_touched_dt_utc}")                                   
