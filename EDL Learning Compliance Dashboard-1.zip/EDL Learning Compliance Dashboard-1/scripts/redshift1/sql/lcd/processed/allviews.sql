DROP VIEW IF EXISTS processed.transcript_core_vw cascade;
CREATE OR REPLACE VIEW processed.transcript_core_vw
AS
select * from source.transcript_core where is_latest_reg_num= True  and is_removed= False;

DROP VIEW IF EXISTS processed.user_ou_core_vw cascade;
CREATE OR REPLACE VIEW processed.user_ou_core_vw 
AS
SELECT * FROM source.user_ou_core;

DROP VIEW IF EXISTS processed.ou_core_vw cascade;
CREATE OR REPLACE VIEW processed.ou_core_vw
AS
select * from source.ou_core where type_id=8;

DROP VIEW IF EXISTS processed.users_core_vw cascade;
CREATE OR REPLACE VIEW processed.users_core_vw 
AS
select * from source.users_core where user_status_id=1 and user_absent = False;

DROP VIEW IF EXISTS processed.training_core_vw cascade;
CREATE OR REPLACE VIEW processed.training_core_vw 
AS
select * from source.training_core where lo_active='Y';

DROP VIEW IF EXISTS processed.training_cf_core_vw cascade;
CREATE OR REPLACE VIEW processed.training_cf_core_vw 
AS
SELECT * FROM source.training_cf_core; 

DROP VIEW IF EXISTS processed.training_local_core_vw cascade;
CREATE OR REPLACE VIEW processed.training_local_core_vw 
AS
SELECT * FROM source.training_local_core where culture_id = 1;

DROP VIEW IF EXISTS processed.transcript_status_local_core_vw cascade;
CREATE OR REPLACE VIEW processed.transcript_status_local_core_vw 
AS
SELECT * FROM source.transcript_status_local_core WHERE culture_id = 1;

DROP VIEW IF EXISTS processed.curriculum_structure_core_vw cascade;
CREATE OR REPLACE VIEW processed.curriculum_structure_core_vw
AS
SELECT * FROM source.curriculum_structure_core;

DROP VIEW IF EXISTS processed.address_core_vw cascade;
CREATE OR REPLACE VIEW processed.address_core_vw
AS
SELECT * FROM source.address_core;
