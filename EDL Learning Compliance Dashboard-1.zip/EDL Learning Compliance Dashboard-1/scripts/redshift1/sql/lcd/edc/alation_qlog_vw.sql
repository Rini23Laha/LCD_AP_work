CREATE OR REPLACE VIEW edc.alation_qlog_vw
AS

select * 
from
qdidatalake.edc.alation_qlog
where default_database = 'lcd' 
with no SCHEMA binding;