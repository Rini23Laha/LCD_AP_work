-- select * from curated.user_courses_vw where user_id = 34697
create or replace view curated.user_courses_vw
as

with 
-- -------------------
-- list of Transcript IDs
-- -------------------
root as (
  select distinct 
      c.transc_user_id  as user_id, 
      c.transc_object_id as object_id,
      c.is_assigned,
      tslc.status_name,
      c.user_lo_min_due_date as user_lo_min_due_date,       
      c.user_lo_comp_dt as user_lo_comp_dt
  from processed.transcript_core_vw c
  join processed.transcript_status_local_core_vw tslc --- ########################  INNE
  on c.user_lo_status_id  = tslc.status_id
)    
-- ----------------------
-- Curriculum Structure with TITLE atatched
-- ----------------------
,struct as (
    select 
        c.curriculum_object_id,
        ctxt.title as curriculum_title,
        ctxt.show_in_reporting as curriculum_show_in_reporting,
        ctxt.training_type as curriculum_training_type,
        c.parent_object_id,
        (select title from curated.training_vw where object_id = c.parent_object_id)::text as parent_title,
        c.object_id,
        otxt.title as object_title,
        otxt.show_in_reporting as object_show_in_reporting,
        otxt.training_type as object_training_type,
        otxt.qualification as object_qualification,
        otxt.validity as object_validity
    from 
        processed.curriculum_structure_core_vw c
          left outer join 
          curated.training_vw otxt on c.object_id = otxt.object_id
          left outer join 
          curated.training_vw ctxt on c.curriculum_object_id = ctxt.object_id
    where 
      c.curriculum_object_id in (select object_id from processed.training_local_core_vw where culture_id = 1) 
      and c.object_id in (select object_id from processed.training_local_core_vw where culture_id = 1) 
      and otxt.title is not null
)   

-- ------------------------------
-- Matches on CURRICULUM
, curr_match as (
    select 
      root.user_id,
      root.is_assigned,
      root.status_name as curriculum_status_name,
      root.user_lo_min_due_date as curriculum_user_lo_min_due_date ,
      root.user_lo_comp_dt as curriculum_user_lo_comp_dt,
      'yes' as is_assigned_to_curriculum,
      struct.curriculum_object_id as curriculum,
      struct.curriculum_title as curriculum_title,
      struct.curriculum_training_type as curriculum_training_type,
      struct.parent_object_id as section,
      struct.parent_title as section_title,
      struct.object_id as course,
      struct.object_title as course_title,
      struct.object_training_type as course_training_type,
      struct.object_qualification as course_qualification,
      struct.object_validity as course_validity
    from 
      root join struct 
      on root.object_id = struct.curriculum_object_id
   --where struct.curriculum_show_in_reporting = true
 )  
--select * from curr_match where user_id=34697
-- -------------------------------------
-- Matches on COURSE
, course_match as 
(
    select 
      root.user_id,
      root.is_assigned,
      root.status_name as course_status_name,
      root.user_lo_min_due_date as course_user_lo_min_due_date ,
      root.user_lo_comp_dt as course_user_lo_comp_dt,  
      'no' as is_assigned_to_curriculum,
      struct.curriculum_object_id as curriculum,
      struct.curriculum_title as curriculum_title,
      struct.curriculum_training_type as curriculum_training_type,
      struct.parent_object_id as section,
      struct.parent_title as section_title,
      struct.object_id as course,
      struct.object_title as course_title,
      struct.object_training_type as course_training_type,
      struct.object_qualification as course_qualification,
      struct.object_validity as course_validity
      ,struct.object_show_in_reporting
    from 
      root join struct 
      on root.object_id = struct.object_id
   --where struct.object_show_in_reporting = true  
)   
--select * from course_match where user_id=34697
-- ===================================
,matches as (
    -- this view takes all courses where the CURRICULUM is assinged to the user
    -- .. then adds in assinged courses where the course does not exists in the above curriculumns
    
    -- (1) curriculum joined results
      select
          curr_match.is_assigned_to_curriculum,
          curr_match.is_assigned,
          curr_match.user_id  --, curr_match.root
          , curr_match.curriculum
          , curr_match.curriculum_title
          , curr_match.curriculum_training_type
          , curr_match.section
          , curr_match.section_title
          , curr_match.course
          , curr_match.course_title
          , curr_match.course_training_type
          , curr_match.course_qualification
          , curr_match.course_validity
          , case when course_match.course is null then 'no' else 'yes' end as is_assigned_course
          
          , curr_match.curriculum_status_name
          , course_match.course_status_name
          , curr_match.curriculum_user_lo_min_due_date
          , course_match.course_user_lo_min_due_date
          , curr_match.curriculum_user_lo_comp_dt
          , course_match.course_user_lo_comp_dt
      from curr_match
          -- add in a flag to tell if the course is also assigned
            left outer join (select distinct user_id,course,course_status_name,course_user_lo_min_due_date,course_user_lo_comp_dt from course_match) as course_match
            on curr_match.user_id = course_match.user_id
              and curr_match.course = course_match.course
               
      UNION ALL
   
    -- (2) course related
    --    (a) find assigned courses from 'Compliance Board' curriculum , that are not in a user's assigned curriculums
            select 
              course_match.is_assigned_to_curriculum
              , course_match.is_assigned
              , course_match.user_id    --, course_match.root
              , course_match.curriculum
              , course_match.curriculum_title
              , course_match.curriculum_training_type
              , case when curriculum_title = 'Compliance Board' then '' else course_match.section end as section
              , case when curriculum_title = 'Compliance Board' then '' else course_match.section_title end as section_title
              , course_match.course
              , course_match.course_title
              , course_match.course_training_type
              , course_match.course_qualification
              , course_match.course_validity
              ,'yes' as is_assigned_course
              ,null::text as curriculum_status_name
              ,course_match.course_status_name
              
              , null::text as curriculum_user_lo_min_due_date
              , course_match.course_user_lo_min_due_date
              , null::text as curriculum_user_lo_comp_dt
              , course_match.course_user_lo_comp_dt
          
            from course_match
            where
            --user_id = 34697 and 
            course_match.curriculum_title = 'Compliance Board'
            and course_match.course not in (select curr_match.course from curr_match where curr_match.user_id = course_match.user_id)
            
)
-- =======================================
-- Final Output
-- =======================================
select 
  user_id,
  is_assigned_to_curriculum,
  is_assigned_course,
  is_assigned,
  curriculum,
  curriculum_title,
  curriculum_training_type,
  section,
  section_title,
  course,
  course_title,
  course_training_type,
  course_qualification,
  course_validity,
  curriculum_status_name,
  course_status_name,
  curriculum_user_lo_min_due_date,
  course_user_lo_min_due_date,
  curriculum_user_lo_comp_dt,
  course_user_lo_comp_dt

from matches
--where course_title is not null
with no schema binding;