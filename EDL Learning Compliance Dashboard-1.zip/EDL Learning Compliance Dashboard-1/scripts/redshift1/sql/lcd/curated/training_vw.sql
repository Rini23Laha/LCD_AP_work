--
-- select * from curated."training_vw" where object_id = 'a6d0ead1-7a69-4dea-b6fb-ed08cdf79f7a'; -- curriculum 'Compliance Board'
-- select * from curated."training_vw" where object_id = '729d5faa-9ccc-467b-a377-2e57a377e84d'; -- course 'Code of Conduct Training and Certification for New Employees'
--select show_in_reporting,field_10,count(*) from curated."training_vw" group by show_in_reporting,field_10

create or replace view curated."training_vw"
as 
-- training_core.user_lo_min_due_date does not exist
  select 
    training_local_core.object_id as object_id ,
    training_local_core.title as title ,
    training_core.object_id as tc_object_id,
    training_core.lo_object_type as training_type,
   
    training_cf_core.object_id as tcf_object_id,
    training_cf_core.field_5 as qualification,
    training_cf_core.field_8 as validity,
    training_cf_core.field_10 as show_in_reporting    
  from 
    processed.training_local_core_vw  as training_local_core
    join 
    processed.training_core_vw  as training_core
    on training_local_core.object_id = training_core.object_id
    join 
    processed.training_cf_core_vw as training_cf_core
    on training_local_core.object_id = training_cf_core.object_id

with no schema binding;