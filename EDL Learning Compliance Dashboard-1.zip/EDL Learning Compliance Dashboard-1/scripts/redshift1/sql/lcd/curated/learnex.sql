drop view if exists curated.learnex cascade;
create OR REPLACE view  curated.learnex as
SELECT usc.user_ref AS employee_number,
       user_core.title AS User_LearnEx_Profile,
       training.field_5 AS Qualification,
       training.title AS Training_Title,
       training.lo_object_type AS Training_Training_Type,
       tslc.status_name AS Status,
       tc.user_lo_min_due_date AS Due_Date,
       tc.user_lo_comp_dt AS Completed,
       training.field_8 AS Training_Course_Validity_in_years,
       curriculum.Curriculum_Title_Curriculum,
       curriculum.Training_Curriculum_Training_Section_Parent,
       tc.transc_object_id
FROM (SELECT * FROM processed.transcript_core_vw) AS tc
  JOIN (SELECT user_id,
               title
        FROM processed.user_ou_core_vw uoc
          JOIN processed.ou_core_vw as uc ON uc.ou_id = uoc.ou_id
        ) AS user_core ON tc.transc_user_id = user_core.user_id
  JOIN processed.users_core_vw usc ON usc.user_id = tc.transc_user_id
  JOIN processed.address_core_vw adc ON usc.user_address_id = adc.address_id
  JOIN (SELECT tc.*,
               field_8,
               title,
               field_5,
               tcf.object_id AS cf_object_id
        FROM processed.training_core_vw AS tc
          JOIN (SELECT * FROM processed.training_cf_core_vw) AS tcf ON tc.object_id = tcf.object_id
          JOIN processed.training_local_core_vw AS tlc ON tc.object_id = tlc.object_id 
        )AS training ON training.object_id = tc.transc_object_id
 
  JOIN (SELECT *
        FROM processed.transcript_status_local_core_vw
        ) AS tslc ON tc.user_lo_status_id = tslc.status_id 
        
  JOIN (SELECT ctc.Curriculum_Title_Curriculum,
               sp.Training_Curriculum_Training_Section_Parent,
               ct.Curriculum_Training_Title,             
               cs.object_id
        FROM processed.curriculum_structure_core_vw AS cs
          JOIN (SELECT title AS Curriculum_Title_Curriculum,
                       object_id
                FROM processed.training_local_core_vw
                ) ctc ON cs.curriculum_object_id = ctc.object_id
          JOIN (SELECT title AS Training_Curriculum_Training_Section_Parent,
                       object_id
                FROM processed.training_local_core_vw
                ) sp ON cs.parent_object_id = sp.object_id
          JOIN (SELECT title AS Curriculum_Training_Title,
                       object_id
                FROM processed.training_local_core_vw
                ) ct ON cs.object_id = ct.object_id
          group by ctc.Curriculum_Title_Curriculum,  sp.Training_Curriculum_Training_Section_Parent, 
         ct.Curriculum_Training_Title, cs.object_id
 
) AS curriculum ON curriculum.object_id = tc.transc_object_id 
and curriculum.curriculum_title_curriculum like '%EHS Group%' 
or curriculum.curriculum_title_curriculum like '%Global Mandatory%'; 