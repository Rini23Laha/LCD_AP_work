drop view if exists curated.training_curriculum_group_vw cascade;
CREATE OR REPLACE VIEW curated.training_curriculum_group_vw 
AS
SELECT usc.user_ref AS employee_number,
       training.field_5 AS qualification,
       training.title AS training_title,
       curriculum.curriculum_title_curriculum,
       training.object_id AS training_object_id,
       tsc.is_assigned AS assigned
FROM processed.transcript_core_vw tsc
  JOIN processed.users_core_vw AS usc ON usc.user_id = tsc.transc_user_id
  JOIN (SELECT tc.object_id,
               tlc.title,
               tcf.field_5
        FROM processed.training_core_vw AS tc
          JOIN processed.training_cf_core_vw AS tcf ON tc.object_id = tcf.object_id
          JOIN processed.training_local_core_vw AS tlc ON tc.object_id = tlc.object_id) AS training ON training.object_id = transc_object_id
  JOIN (SELECT ctc.title AS curriculum_title_curriculum,
               sp.title AS training_curriculum_training_section_parent,
               ct.title AS curriculum_training_title,
               cs.object_id
        FROM processed.curriculum_structure_core_vw AS cs
          JOIN (SELECT title, object_id FROM processed.training_local_core_vw) AS ctc ON cs.curriculum_object_id = ctc.object_id
          JOIN (SELECT title, object_id FROM processed.training_local_core_vw) AS sp ON cs.parent_object_id = sp.object_id
          JOIN (SELECT title, object_id FROM processed.training_local_core_vw) AS ct ON cs.object_id = ct.object_id
        GROUP BY ctc.title,
                 sp.title,
                 ct.title,
                 cs.object_id) AS curriculum ON curriculum.object_id = tsc.transc_object_id
             WHERE curriculum.curriculum_title_curriculum LIKE '%EHS Group%'
             OR    curriculum.curriculum_title_curriculum LIKE '%Global Mandatory%'
             or    curriculum_title_curriculum like '%Compliance Board%'
             ;