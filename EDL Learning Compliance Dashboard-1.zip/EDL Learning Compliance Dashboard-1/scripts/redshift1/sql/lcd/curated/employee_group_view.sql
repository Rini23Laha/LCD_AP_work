drop view if exists curated.employee_group_view cascade;
create OR REPLACE view  curated.employee_group_view as
SELECT transc_user_id,
       usc.user_ref AS employee_number,
       cir.Curriculum_Title_Curriculum AS Curriculum_Title,
       tsc.is_assigned as assigned

FROM processed.transcript_core_vw tsc
JOIN (
    SELECT object_id
    FROM processed.training_core_vw
    WHERE lo_object_type = 'PRGM'
) tac ON tac.object_id = tsc.transc_object_id
JOIN (
    SELECT ctc.Curriculum_Title_Curriculum, cs.curriculum_object_id
    FROM processed.curriculum_structure_core_vw AS cs
    JOIN (
        SELECT title AS Curriculum_Title_Curriculum, object_id
        FROM processed.training_local_core_vw
    ) ctc ON cs.curriculum_object_id = ctc.object_id
) cir ON cir.curriculum_object_id = tac.object_id
JOIN processed.users_core_vw usc ON usc.user_id = tsc.transc_user_id
--where cir.Curriculum_Title_Curriculum like '%EHS Group%' or cir.Curriculum_Title_Curriculum like '%Global Mandatory%'
GROUP BY transc_user_id, cir.Curriculum_Title_Curriculum, employee_number,assigned;