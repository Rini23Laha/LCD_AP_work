--select * from curated.qliksense_vw where user_id = '34697'
CREATE OR REPLACE VIEW curated.qliksense_vw 
AS
SELECT c.user_id,
       u.user_ref as employee_number,
       u.user_email as user_email,
       u.ou_id,
       u.ou_title as title,
       u.ou_parent_id as parent_id,
       c.is_assigned_to_curriculum as is_assigned_to_curriculum,
       c.is_assigned_course as is_assigned_course,
       c.is_assigned as is_assigned ,
       c.curriculum as curriculum,
       c.curriculum_title as curriculum_title,
       c.section as section,
       c.section_title as section_title,
       c.course as course,
       c.course_title as course_title,
       c.course_qualification as course_qualification,
       c.course_validity as course_validity,
       c.curriculum_training_type as curriculum_training_type,
       c.course_training_type as course_training_type,
       c.curriculum_status_name as curriculum_status_name,
       c.course_status_name as course_status_name,
       c.curriculum_user_lo_min_due_date as curriculum_user_lo_min_due_date,
       c.course_user_lo_min_due_date as course_user_lo_min_due_date,
       c.curriculum_user_lo_comp_dt as curriculum_user_lo_comp_dt,
       c.course_user_lo_comp_dt as course_user_lo_comp_dt
FROM curated.user_courses_vw c
  JOIN curated.users_vw u ON c.user_id = u.user_id WITH no SCHEMA binding;