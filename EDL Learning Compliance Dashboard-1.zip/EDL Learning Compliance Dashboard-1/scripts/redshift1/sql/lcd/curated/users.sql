create or replace view curated.users_vw
as
select
  users_core.user_id,
  users_core.user_ref,
  users_core.user_email,
  user_ou_core.ou_id,
  ou_core.title as ou_title,
  ou_core.parent_id as ou_parent_id
from 
processed.users_core_vw as users_core
join
processed.user_ou_core_vw as user_ou_core
on users_core.user_id = user_ou_core.user_id
join 
processed.ou_core_vw as ou_core
on user_ou_core.ou_id = ou_core.ou_id
with no schema binding;