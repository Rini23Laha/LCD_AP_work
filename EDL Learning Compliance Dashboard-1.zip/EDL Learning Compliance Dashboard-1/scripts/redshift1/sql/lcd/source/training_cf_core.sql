CREATE TABLE IF NOT EXISTS source.training_cf_core
(
	object_id VARCHAR (1000) ENCODE lzo
    ,field_8 VARCHAR (1000) ENCODE lzo
    ,field_5 VARCHAR (1000)   ENCODE lzo
	,field_10 BOOLEAN  ENCODE ZSTD
    ,_last_touched_dt_utc TIMESTAMP WITHOUT TIME ZONE ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (object_id)
)
DISTSTYLE KEY
DISTKEY (object_id)
SORTKEY (_last_touched_dt_utc)
;