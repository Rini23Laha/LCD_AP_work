CREATE TABLE IF NOT EXISTS source.culture_core
(
	culture_id INTEGER ENCODE AZ64 
    ,culture_name VARCHAR  (1000)
    ,descr  VARCHAR  (5000)
    ,_last_touched_dt_utc timestamp
    ,api_name VARCHAR(500)
    ,file_name VARCHAR(500)
    ,ingested_timestamp timestamp
    ,PRIMARY KEY (culture_id)
)
;
