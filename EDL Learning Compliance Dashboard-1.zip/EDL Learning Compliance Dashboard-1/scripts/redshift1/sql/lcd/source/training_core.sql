CREATE TABLE IF NOT EXISTS source.training_core
(
	lo_active VARCHAR (100) ENCODE lzo
    ,lo_hours  float
    ,object_id VARCHAR (1000) ENCODE lzo
	,related_lo_id VARCHAR (1000) ENCODE lzo
    ,lo_object_type VARCHAR (1000) ENCODE lzo
    ,lo_status_type VARCHAR (1000) ENCODE lzo
    ,lo_language_id bigint ENCODE az64
    ,lo_location_id bigint ENCODE az64
    ,_last_touched_dt_utc TIMESTAMP WITHOUT TIME ZONE ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (object_id)
)
DISTSTYLE KEY
DISTKEY (object_id)
SORTKEY (_last_touched_dt_utc)
;
