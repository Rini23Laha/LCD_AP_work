CREATE TABLE IF NOT EXISTS source.user_ou_core
(
	user_id BIGINT   ENCODE az64
    ,ou_id BIGINT   ENCODE az64
    ,ou_type_id INTEGER ENCODE AZ64  
	,status_id INTEGER ENCODE AZ64 
    ,_last_touched_dt_utc TIMESTAMP WITHOUT TIME ZONE ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (user_id, ou_id)
)
DISTSTYLE KEY
DISTKEY (user_id)
SORTKEY (_last_touched_dt_utc)
;

