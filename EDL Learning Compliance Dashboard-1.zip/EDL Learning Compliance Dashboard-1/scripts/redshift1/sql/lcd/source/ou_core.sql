CREATE TABLE IF NOT EXISTS source.ou_core
(
	title VARCHAR  (1000) ENCODE lzo
    ,ou_id BIGINT  ENCODE az64
    ,parent_id INTEGER ENCODE AZ64  
	,type_id INTEGER ENCODE AZ64
    ,_last_touched_dt_utc timestamp ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (ou_id)
)
DISTSTYLE KEY
DISTKEY (ou_id)
SORTKEY (_last_touched_dt_utc)
;
