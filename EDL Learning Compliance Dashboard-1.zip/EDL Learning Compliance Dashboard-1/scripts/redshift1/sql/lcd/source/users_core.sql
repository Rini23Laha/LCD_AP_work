CREATE TABLE IF NOT EXISTS source.users_core
(
	user_id INTEGER   ENCODE az64
    ,user_ref VARCHAR (1000) ENCODE lzo
    ,user_type_id INTEGER ENCODE AZ64  
	,user_status_id INTEGER ENCODE AZ64
    ,user_address_id INTEGER ENCODE AZ64
    ,user_email VARCHAR (1000) ENCODE lzo
    ,user_mgr_id float 
    ,user_appr_id bigint ENCODE az64
    ,user_i_mgr_id float
    ,user_absent BOOLEAN  ENCODE ZSTD
    ,_last_touched_dt_utc  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,api_name VARCHAR (1000) ENCODE lzo
    ,file_name VARCHAR(1000) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (user_id)
)

DISTSTYLE KEY
DISTKEY (user_id)
SORTKEY (_last_touched_dt_utc)
;