CREATE TABLE IF NOT EXISTS source.curriculum_structure_core
(
	curriculum_object_id VARCHAR  (1000) ENCODE lzo
    ,parent_object_id VARCHAR  (1000) ENCODE lzo
    ,object_id VARCHAR (1000)   ENCODE lzo
    ,_last_touched_dt_utc  TIMESTAMP WITHOUT TIME ZONE ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (curriculum_object_id,parent_object_id,object_id)
)
DISTSTYLE KEY
DISTKEY (object_id)
SORTKEY (_last_touched_dt_utc)
;
