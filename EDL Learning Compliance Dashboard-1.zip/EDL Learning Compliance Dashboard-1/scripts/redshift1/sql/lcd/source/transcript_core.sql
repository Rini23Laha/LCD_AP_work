CREATE TABLE IF NOT EXISTS source.transcript_core
(
	transc_object_id VARCHAR  (1000) ENCODE lzo
    ,reg_num INTEGER ENCODE AZ64
    ,transc_user_id INTEGER ENCODE AZ64 
    ,is_latest_reg_num BOOLEAN   ENCODE ZSTD
	,is_assigned BOOLEAN   ENCODE ZSTD
	,is_removed BOOLEAN  ENCODE ZSTD
    ,user_lo_assigned_dt VARCHAR(500)  ENCODE lzo
    ,user_lo_comp_dt  VARCHAR(500)  ENCODE lzo
    ,user_lo_min_due_date  VARCHAR(500)  ENCODE lzo
    ,user_lo_status_id  BIGINT ENCODE AZ64
    ,user_lo_start_dt   VARCHAR(500)  ENCODE lzo
    ,_last_touched_dt_utc TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,user_lo_assigned_dt_utc TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,user_lo_comp_dt_utc TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,user_lo_min_due_date_utc TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,user_lo_start_dt_utc TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,ingested_timestamp TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (transc_object_id,transc_user_id,reg_num)
)
DISTSTYLE KEY
DISTKEY (transc_object_id)
SORTKEY (_last_touched_dt_utc)
;  