CREATE TABLE IF NOT EXISTS source.address_core
(
	city VARCHAR  (1000) ENCODE lzo
    ,country_code VARCHAR  (1000) ENCODE lzo
    ,address_id INTEGER ENCODE AZ64  
    ,_last_touched_dt_utc TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (address_id)
)
DISTSTYLE KEY
DISTKEY (address_id)
SORTKEY (_last_touched_dt_utc)
;
