CREATE TABLE IF NOT EXISTS source.transcript_status_local_core
(
	culture_id BIGINT ENCODE AZ64
    ,is_default BOOLEAN  ENCODE ZSTD
    ,status_id BIGINT ENCODE AZ64  
	,status_name  VARCHAR  (1000) ENCODE lzo
    ,_last_touched_dt_utc TIMESTAMP WITHOUT TIME ZONE ENCODE az64
    ,api_name VARCHAR (500) ENCODE lzo
    ,file_name VARCHAR(500) ENCODE lzo
    ,ingested_timestamp  TIMESTAMP WITHOUT TIME ZONE   ENCODE az64
    ,PRIMARY KEY (culture_id,status_id)
)
DISTSTYLE KEY
DISTKEY (culture_id)
SORTKEY (_last_touched_dt_utc)
;
