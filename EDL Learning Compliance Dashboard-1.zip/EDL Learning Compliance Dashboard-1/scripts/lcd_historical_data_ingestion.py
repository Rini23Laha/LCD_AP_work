import sys
from enum import Enum
import logging
from time import sleep
from awsglue.utils import getResolvedOptions
import boto3
from datetime import datetime
import pandas as pd
import json
import boto3
import traceback
import logging
from botocore.exceptions import ClientError
import os
from datetime import timedelta as timedelta


# initialising logger
if len(logging.getLogger().handlers) > 0:
    logging.getLogger().setLevel(logging.INFO)
else:
    logging.basicConfig(
        format='[%(levelname)s][%(filename)s] [%(funcName)s] [%(lineno)d] %(message)s', level=logging.INFO)

input_path = "s3://{bucket_name}/{prefix}{api_name}/{date_str}/"
args = getResolvedOptions(
    sys.argv, ['JOB_NAME', 'api_name', 'temp_path', 'start_date', 'end_date', 'input_bucket','input_bucket_prefix','region', 'env', 'is_extract_data','is_full_load_','glue_workflow_name'])

glue_client = boto3.client('glue', region_name=args['region'])
workflow_name=args['glue_workflow_name']



def has_new_files(input_bucket, prefix=None):
    """
    Lists the objects in a bucket, optionally filtered by a prefix.

    :param bucket: The bucket to query. This is a Boto3 Bucket resource.
    :param prefix: When specified, only objects that start with this prefix are listed.
    :return: boolean whether files are present of not
    """
    try:
        if not prefix:
            objects = list(input_bucket.objects.all())
        else:
            objects = list(input_bucket.objects.filter(
                Prefix=prefix, Delimiter='/'))
            logging.info(
                f"Found keys {objects} No of keys found {len(objects)}")
            if len(objects):
                return True
            else:
                return False
    except ClientError:
        logging.error(f"EXCEPTION - {traceback.format_exc()}")


def wait_for_sf_to_complete(client, execution_arn):
    while True:
        response = client.describe_execution(
            executionArn=execution_arn
        )
        status = response['status']
        logging.info("waiting for stepfunction", status)
        if status.upper().__eq__("SUCCEEDED") or status.upper().__eq__("FAILED") or status.upper().__eq__("STOPPED"):
            break
        else:
            sleep(200)





def list_s3_objects(input_bucket, prefix=None):
    """
    Lists the objects in a bucket, optionally filtered by a prefix.

    :param bucket: The bucket to query. This is a Boto3 Bucket resource.
    :param prefix: When specified, only objects that start with this prefix are listed.
    :return: boolean whether files are present of not
    """
    try:
        if not prefix:
            objects = list(input_bucket.objects.all())
        else:
            objects = list(input_bucket.objects.filter(
                Prefix=prefix, Delimiter='/'))
            print("Processing keys ", objects)
            if len(objects):
                return objects
    except ClientError:
        print(
            "ERROR: Couldn't get objects for bucket '%s'.", input_bucket.name)


def copy_files_to_target(bucket, prefix, s3_resource, target_path):
    '''
    one time activity - to be deleted
    '''
    logging.info("copying files from bucket {} prefix {} ",
                 bucket.name, prefix)
    file_list = list_s3_objects(input_bucket=bucket, prefix=prefix)
    if file_list is not None:
        copy_files(s3_resource, file_list, bucket, target_path)


def copy_files(s3_resource, file_list, bucket, target_path):
    #path_format = "{bucket_name}/{year}/{month}/{day}/{key}"
    path_format = "{prefix}{api_name}/{date_str}/{key}"
    target_path_prefix = target_path.partition(
        "/")[2].split('/', 2)[-1]
    for file in file_list:
        if file.key != '':
            filename = file.key.split('/')[-1]
            file_date = filename.split('_')[1][0:8]
            path = path_format.format(
                prefix=target_path_prefix, api_name=args['api_name'], date_str=file_date, key=file.key.rsplit('/', 1)[1])
            logging.info("copying file to path ", path)
            copy_source = {
                'Bucket': bucket.name,
                'Key': file.key
            }
            s3_resource.meta.client.copy(copy_source, bucket.name, path)



def trigger_glue_workflow(glue_client, workflowName, properties_dict):
    response = glue_client.start_workflow_run(
    Name=workflowName,
    RunProperties=properties_dict
    )   
    return response


def glue_workflow_status(glue_client, run_id):
    while True:
        response = glue_client.get_workflow_run(
        Name=args['glue_workflow_name'],
        RunId=run_id,
        IncludeGraph=False)
        status = response['Run']['Status']        
        logging.info(response)
        if status.upper().__eq__("COMPLETED") or status.upper().__eq__("ERROR") or status.upper().__eq__("STOPPED"):
            break
        else:
            logging.info("waiting for job to complete 200s")
            sleep(100)
    
def load_data():

    if not args['start_date'] or not args['end_date']:
        raise ("Please pass the start_date and  end_date in the arguments - format %Y-%m-%d")
    print("args['start_date']",args['start_date'])
    start_dt_utc = datetime.strptime(args['start_date'], "%Y-%m-%d").date()
    print("start_dt_utc",start_dt_utc)
    print("args['end_date']",args['end_date'])
    end_dt_utc = datetime.strptime(args['end_date'], "%Y-%m-%d").date()
    print("end_last_touched_dt_utc",end_dt_utc)
    daterange = pd.date_range(start_dt_utc, end_dt_utc) 
    api = args['api_name']
    
    
    if start_dt_utc <= end_dt_utc:     
            input_dict = {
                'temp_path': args['temp_path'], 
                'env': args['env'], 
                # 'is_historical_data': "True",
                'is_full_load_':"false",
                'api_name':args['api_name'],
                'input_bucket':args['input_bucket'],
                'input_bucket_prefix':args['input_bucket_prefix'],
                'api_name':api,
                'start_date':args['start_date'],
                'end_date':args['end_date']
                }
            
            # for single_date in daterange:
                # logging.info("single_date", single_date)                                            
                # try:
                    
            input_dict['start_date']=str(datetime.strptime(input_dict['start_date'], "%Y-%m-%d").date())
            print("input_dict_start",input_dict['start_date'])
            input_dict['end_date']=str(datetime.strptime(input_dict['end_date'], "%Y-%m-%d").date())
            print("input_dict_start",input_dict['end_date'])
            response=trigger_glue_workflow(glue_client=glue_client, workflowName=workflow_name,properties_dict=input_dict)
                    
                    # CONDITION="&$filter=_last_touched_dt_utc gt cast ({single_date})"
            logging.info("Triggered the WF id ",response['RunId'])
            glue_workflow_status(
                        glue_client=glue_client, run_id=response['RunId'])
                # except Exception as e:                    
                    # logging.error(
                    #     f"Exception occured while triggering the workflow, retring once {e}")
                    # response=trigger_glue_workflow(glue_client=glue_client, workflowName=workflow_name,properties_dict=input_dict)
                    # glue_workflow_status(glue_client=glue_client, run_id=response['RunId'])
            # else:
            #         logging.info(
            #             f"No files found for the api")
       
    else:
        logging.info(
            f"No files found for the api")
        raise ("start date should be older than end date")

load_data()
