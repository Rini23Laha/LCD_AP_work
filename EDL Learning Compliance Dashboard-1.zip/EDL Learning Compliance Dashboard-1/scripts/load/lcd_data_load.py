'''
    title : data_load.py
    description : loads the parquet files into redshift
    functionality :
        a. For the given API if the parquet file found on the given path (output_path),
            applies the transformation
            applies the mapping(column_name: data_type) defined
            and upserts the data to Redshift
            Writes the transformed data into s3 - processed path
    version : 1.0
    usage : Invoked by RedshiftDataLoad Glue job
    python_version : 3.0
'''
import logging
import sys

from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import boto3
from datetime import datetime,timedelta

from awsglue.transforms import *
from configs import mappings

from transform.transformer_factory import transformer_factory

from configs import constants
from utilities import utils as utils

sns_arn="aws:sns"
if len(logging.getLogger().handlers) > 0:
    logging.getLogger().setLevel(logging.INFO)
else:
    logging.basicConfig(
        format='[%(levelname)s][%(filename)s] [%(funcName)s] [%(lineno)d] %(message)s', level=logging.INFO)

if '--WORKFLOW_NAME' in sys.argv and '--WORKFLOW_RUN_ID' in sys.argv:
    args = getResolvedOptions(
        sys.argv, [ 'raw_bucket', 'processed_bucket', 'temp_path', "env", "redshift_role","JOB_NAME", "sns_arn", "account_id", "region_name", "servicenow_sns_topic", 'WORKFLOW_NAME',
                            'WORKFLOW_RUN_ID','path_prefix'])
    # input_path = args['output_path']+prefix
    raw_files_bucket = args['raw_bucket']
    processed_files_bucket = args['processed_bucket']
    prefix=args['path_prefix']
    env = args['env']
    run_id = args['JOB_RUN_ID']
    job_name = args['JOB_NAME']
    sns_arn = args['sns_arn']
    account_id = args['account_id']
    region = args['region_name']
    servicenow_lambdafn = args['servicenow_sns_topic']
    

    glue_client = boto3.client('glue', region_name=args['region_name'])
    workflow_args=glue_client.get_workflow_run_properties( Name=args['WORKFLOW_NAME'], RunId=args['WORKFLOW_RUN_ID'])["RunProperties"]
    if 'aws:eventIds' in workflow_args:
        workflow_args['is_historical_data'] = 'False'
        workflow_args['is_full_load_'] = 'False'
        args['is_historical_data'] = 'False'
        args['is_full_load_']='False'
        args['api_name'] = workflow_args['api_name']
        
        
    elif 'start_date' in workflow_args and 'end_date' and 'is_full_load_' in workflow_args :
           workflow_args['is_historical_data'] = 'True'
           workflow_args['is_full_load_'] = 'False'
           args['is_full_load_']='False'
           args['is_historical_data']='True'
           start_date=''
           end_date=''
           args['start_date'] = workflow_args['start_date']
           args['end_date'] = workflow_args['end_date']    
            
    else:
        workflow_args['is_historical_data']='True'
        args['is_historical_data'] = 'True'
        args['is_full_load_']='True'
    logging.info(workflow_args)
else:
    logging.error("Job should trigger from the workflow id")
    raise Exception("GlueJob Not Started by the workflow")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
s3_resource = utils.get_s3_resource()

api=  workflow_args['api_name']
bucket = s3_resource.Bucket(args["raw_bucket"])
SCHEMA = mappings.redshift_schema_name
date_str = datetime.now().strftime("%Y%m%d %H:%M:%S").replace(" ","_")


if workflow_args['is_historical_data'].lower().__eq__('true'): 
    args['is_historical_data'] = 'True'
    current_time = datetime.now()
    print(type(current_time))
    date_obj = current_time
    
elif 'start_date' in workflow_args and 'end_date' and 'is_full_load_' in workflow_args :
    current_time = datetime.now()
    date_obj = current_time
else:
    args['is_historical_data'] = 'False'
    current_time = datetime.now()
    date_obj = current_time  

tables = mappings.api_table_mapping.get(api).keys()
logging.info(f"loading data into tables - {tables}")
is_historical_data=args['is_historical_data']
is_full_load_=args['is_full_load_']

if is_historical_data.lower() == 'true' and is_full_load_.lower()== 'true':          
    s3_path=constants.historical_s3_raw_data_path_format.format(bucket=raw_files_bucket,table_name=api, prefix=prefix,year=date_obj.year,month=date_obj.month,day=date_obj.day,api_name=api)   

elif is_historical_data.lower() == 'true' and is_full_load_.lower()== 'false' :
    s3_path=constants.s3_raw_data_path_format.format(bucket=raw_files_bucket, prefix=prefix,api_name=api,table_name=api)
    archive_base_path=constants.s3_raw_data_archive_path_prefix_format.format(table_name=api, prefix=prefix,api_name=api)
else:
    # s3_path=constants.historical_s3_raw_data_path_format.format(bucket=raw_files_bucket,table_name=api, prefix=prefix,year=date_obj.year,month=date_obj.month,day=date_obj.day,api_name=api)
    s3_path=constants.s3_raw_data_path_format.format(bucket=raw_files_bucket, prefix=prefix,api_name=api,table_name=api)
    # archive_path=constants.historical_s3_raw_data_path_format.format(bucket=raw_files_bucket,table_name=api, prefix=prefix,api_name=api)
    archive_base_path=constants.s3_raw_data_archive_path_prefix_format.format(table_name=api, prefix=prefix,api_name=api)
logging.info(f"Reading the raw file- raw file {s3_path}")

def execute_insert(trasnfromered_s3_file_frame, table):
    load_data_to_redshift = glueContext.write_dynamic_frame.from_jdbc_conf(
        frame=trasnfromered_s3_file_frame,
        catalog_connection=mappings.glue_redshift_connection_name,
        connection_options={
           #"preactions": pre_query,
            "dbtable": SCHEMA+"."+table,
            "database": mappings.redshift_database_name,
            "aws_iam_role": args['redshift_role']
        },
        redshift_tmp_dir=args["temp_path"],
        transformation_ctx="load_data_to_redshift")
    logging.info("executed the insert logic")

    
## reading the data from s3
dy_dataframe_read_from_S3 = glueContext.create_dynamic_frame.from_options(
        connection_type="s3",
        format="parquet",
        connection_options={"paths": [s3_path], "recurse": False,
                            "groupFiles": "inPartition", "useS3ListImplementation": True},
        transformation_ctx="dy_dataframe_read_from_S3")
logging.info(f"Reading the data from the files {s3_path}")
try:
    for table in tables:
        logging.info(f"loading the data into redshift table : {table}")
        if is_historical_data.lower() == 'true' and is_full_load_.lower()== 'true':  
            processed_bucket_s3_path=constants.s3_processed_data_path_format.format(bucket=processed_files_bucket, prefix=prefix,year=date_obj.year,month=date_obj.month,day=date_obj.day,api_name=api,table_name=table)
        
        elif is_historical_data.lower() == 'true' and is_full_load_.lower()== 'false' :
            processed_bucket_s3_path=constants.s3_processed_data_path_format.format(bucket=processed_files_bucket, prefix=prefix,year=date_obj.year,month=date_obj.month,day=date_obj.day,api_name=api,table_name=table)
        
        else:
            processed_bucket_s3_path=constants.s3_processed_data_path_format.format(bucket=processed_files_bucket, prefix=prefix,year=date_obj.year,month=date_obj.month,day=date_obj.day,api_name=api,table_name=table)


        logging.info(f"using the  s3 path {s3_path}")
        parque_files_prefix=s3_path.split('/',3)[-1]
        print(parque_files_prefix)
        raw_files_list=utils.list_s3_objects(input_bucket=bucket,prefix=parque_files_prefix) 
        print(raw_files_list)
        transformer_obj=transformer_factory.get_transformer(api_name=api)
        logging.info("before_transformations")
        dy_dataframe_read_from_S3.show(5)
        transformed_df= transformer_obj.transform(spark_session=spark,glue_dyn_frame=dy_dataframe_read_from_S3,table_name=table,job_args=args)   
        print(transformed_df)
        transformed_df=transformed_df.distinct().coalesce(1)
        transformed_df.show(1)
        transformer_obj.save_trasformed_data(spark_dataframe=transformed_df,glueContext=glueContext,context_name=table,s3_path=processed_bucket_s3_path)
        
        ingested_timestamp = datetime.now()
        transformed_df = transformed_df.withColumn("ingested_timestamp", lit(ingested_timestamp))         
        transformed_dy_df = DynamicFrame.fromDF(
                    transformed_df, glueContext, 'transformed_dy_df1')
        transformed_dy_df.show(5)
     
        if table.__eq__("data_quality"):
           if transformed_dy_df.count() > 0:  
               execute_insert(trasnfromered_s3_file_frame=transformed_dy_df,table=table)
           utils.move_and_delete(s3_resource=s3_resource,bucket=bucket, file_list=raw_files_list, dest_path=processed_bucket_s3_path.split('/',3)[-1])
           continue
        if is_historical_data.lower() == 'true' and is_full_load_.lower()== 'true':
            pre_query = """truncate table {schema}."{target_table}";drop table if exists  {schema}."{stage_table}_{date_str}";create  table  {schema}."{stage_table}_{date_str}" as select * from {schema}."{target_table}" LIMIT 0;""".format(stage_table="stage_"+table, target_table=table, date_str=date_str, schema=SCHEMA)    
            logging.info(pre_query)
            post_query = """begin;delete from {schema}."{target_table}" using {schema}."{stage_table}_{date_str}" as {stage_table} where {condition};insert into {schema}."{target_table}" select * from {schema}."{stage_table}_{date_str}"; drop table if exists {schema}."{stage_table}_{date_str}"; end;""".format(stage_table="stage_"+table, schema=SCHEMA, target_table=table, date_str=date_str, condition=mappings.table_unique_field.get(table))    
            logging.info(post_query)
            table_name=SCHEMA+".stage_"+table+"_"+date_str
            connection_options={
                    "preactions": pre_query,
                    "dbtable": table_name,               
                    "database": mappings.redshift_database_name,
                    "postactions": post_query,  
                    "aws_iam_role":  args['redshift_role']
                }
            print('historical_data')
            
        elif is_historical_data.lower() == 'true' and is_full_load_.lower()== 'false' :
            
            pre_query = """drop table if exists  {schema}."{stage_table}_{date_str}";create  table  {schema}."{stage_table}_{date_str}" as select * from {schema}."{target_table}" LIMIT 0;""".format(stage_table="stage_"+table, target_table=table, date_str=date_str, schema=SCHEMA)    
            logging.info(pre_query)
            post_query = """begin;delete from {schema}."{target_table}" using {schema}."{stage_table}_{date_str}" as {stage_table} where {condition};insert into {schema}."{target_table}" select * from {schema}."{stage_table}_{date_str}"; drop table if exists {schema}."{stage_table}_{date_str}"; end;""".format(stage_table="stage_"+table, schema=SCHEMA, target_table=table, date_str=date_str, condition=mappings.table_unique_field.get(table))    
            logging.info(post_query)
            print("delta_data")
            print("delta_historical")
            table_name=SCHEMA+".stage_"+table+"_"+date_str
            connection_options={
                "preactions": pre_query,
                "dbtable": table_name,               
                "database": mappings.redshift_database_name,
                "postactions": post_query,
                "aws_iam_role":  args['redshift_role']
                }
            print("delta_historical")
        
        
        else:
            pre_query = """drop table if exists  {schema}."{stage_table}_{date_str}";create  table  {schema}."{stage_table}_{date_str}" as select * from {schema}."{target_table}" LIMIT 0;""".format(stage_table="stage_"+table, target_table=table, date_str=date_str, schema=SCHEMA)    
            logging.info(pre_query)
            post_query = """begin;delete from {schema}."{target_table}" using {schema}."{stage_table}_{date_str}" as {stage_table} where {condition};insert into {schema}."{target_table}" select * from {schema}."{stage_table}_{date_str}"; drop table if exists {schema}."{stage_table}_{date_str}"; end;""".format(stage_table="stage_"+table, schema=SCHEMA, target_table=table, date_str=date_str, condition=mappings.table_unique_field.get(table))    
            logging.info(post_query)
            table_name=SCHEMA+".stage_"+table+"_"+date_str
            connection_options={
                "preactions": pre_query,
                "dbtable": table_name,               
                "database": mappings.redshift_database_name,
                "postactions": post_query,
                "aws_iam_role":  args['redshift_role']
            }
        try:
            load_data_to_redshift = glueContext.write_dynamic_frame.from_jdbc_conf(
                frame=transformed_dy_df,
                catalog_connection=mappings.glue_redshift_connection_name,
                connection_options=connection_options,
                redshift_tmp_dir=args["temp_path"],
                transformation_ctx="load_data_to_redshift")
            logging.info("executed the upsert")
        except Exception as e:
            if "does not exist" in str(e):
                raise RuntimeError(f"{table} table doesn't exists")           
                #execute_insert(trasnfromered_s3_file_frame=transformed_dy_df, table=table)
            else:
                error_message=f"{api} :Error occured while loading the data in raw bucket to redshift table"
                logging.error(error_message,exc_info=True)
                logging.info(str(raw_files_list))
                utils.handle_service_now_ticket_generation(exception = error_message, job_name = args.get("JOB_NAME"), sns_arn = args.get("sns_arn"), account_id = args.get("account_id"), region = args.get("region_name"), run_id = args.get("WORKFLOW_RUN_ID"), servicenow_lambdafn = args.get("servicenow_sns_topic"),dynamo_db_table_name='lcd_exceptions')
                raise RuntimeError(e)
   
    try:
        if not raw_files_list and raw_files_list is None : 
            logging.error("No files found to process !!!")
            #raise RuntimeError(no_file_found_msg)
        else:
            if is_historical_data.lower() == 'true' and is_full_load_.lower()== 'true':
                    logging.info("archive not required for full load")                
            elif  is_historical_data.lower() == 'true' and is_full_load_.lower()== 'false':
                logging.info(f"Archiving files to path= {s3_path}")
                utils.move_and_delete(s3_resource=s3_resource,bucket=bucket, file_list=raw_files_list, dest_path=archive_base_path)
                logging.info("archive done")
                print("historical_delta_data")
            else:
                logging.info(f"s3 path archiving {s3_path}")
                utils.move_and_delete(s3_resource=s3_resource,bucket=bucket, file_list=raw_files_list, dest_path=archive_base_path)
                logging.info("archive done for delta")
    except Exception as e:
        logging.error(e,exc_info=True)

    
    job.commit()

except Exception as e:
      logging.error('Exception raised while loading data in redshift table', exc_info=True)
      utils.handle_service_now_ticket_generation(exception = str(e), job_name = args.get("JOB_NAME"), sns_arn = args.get("sns_arn"), account_id = args.get("account_id"), region = args.get("region_name"), run_id = args.get("WORKFLOW_RUN_ID"), servicenow_lambdafn = args.get("servicenow_sns_topic"),dynamo_db_table_name='lcd_exceptions')
      raise e
  
  